<?xml version="1.0" encoding="ISO-8859-1"?>
<!--Edificios de la D.G. del Catastro.-->
<gml:FeatureCollection gml:id="ES.SDGC.BU"  xmlns:ad="urn:x-inspire:specification:gmlas:Addresses:3.0" xmlns:base="urn:x-inspire:specification:gmlas:BaseTypes:3.2" xmlns:bu-core2d="http://inspire.jrc.ec.europa.eu/schemas/bu-core2d/2.0" xmlns:bu-ext2d="http://inspire.jrc.ec.europa.eu/schemas/bu-ext2d/2.0" xmlns:cp="urn:x-inspire:specification:gmlas:CadastralParcels:3.0" xmlns:el-bas="http://inspire.jrc.ec.europa.eu/schemas/el-bas/2.0" xmlns:el-cov="http://inspire.jrc.ec.europa.eu/schemas/el-cov/2.0" xmlns:el-tin="http://inspire.jrc.ec.europa.eu/schemas/el-tin/2.0" xmlns:el-vec="http://inspire.jrc.ec.europa.eu/schemas/el-vec/2.0" xmlns:gco="http://www.isotc211.org/2005/gco" xmlns:gmd="http://www.isotc211.org/2005/gmd" xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:gmlcov="http://www.opengis.net/gmlcov/1.0" xmlns:gn="urn:x-inspire:specification:gmlas:GeographicalNames:3.0" xmlns:gsr="http://www.isotc211.org/2005/gsr" xmlns:gss="http://www.isotc211.org/2005/gss" xmlns:gts="http://www.isotc211.org/2005/gts" xmlns:swe="http://www.opengis.net/swe/2.0" xmlns:xlink="http://www.w3.org/1999/xlink"  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://inspire.jrc.ec.europa.eu/schemas/bu-ext2d/2.0 http://inspire.ec.europa.eu/draft-schemas/bu-ext2d/2.0/BuildingExtended2D.xsd">
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.000100300VJ56H_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455483.99 4369433.23</gml:lowerCorner>
         <gml:upperCorner>455495.42 4369444.89</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2017-03-15T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>000100300VJ56H_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=000100300VJ56H&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=000100300VJ56H&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.000100300VJ56H_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17"> 455490.72 4369433.23 455483.99 4369440.92 455485.02 4369441.79 455484.81 4369442.4 455484.75 4369443.25 455484.81 4369443.78 455485.11 4369444.37 455485.32 4369444.6 455485.46 4369444.7 455485.91 4369444.86 455486.26 4369444.85 455486.69 4369444.78 455487.42 4369444.51 455487.87 4369444.2 455488.69 4369444.89 455495.42 4369437.54 455490.72 4369433.23</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.001600800VJ56H_PI.2">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455642.65 4367958.2</gml:lowerCorner>
         <gml:upperCorner>455649.95 4367965.7</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>001600800VJ56H_PI.2</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=001600800VJ56H&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=001600800VJ56H&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.001600800VJ56H_PI.2" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15"> 455646.92 4367965.7 455649.95 4367962.93 455645.7 4367958.2 455645.11 4367958.73 455644.97 4367958.57 455644.52 4367958.32 455644 4367958.25 455643.5 4367958.39 455643.09 4367958.7 455642.82 4367959.15 455642.75 4367959.66 455642.87 4367960.16 455643.12 4367960.52 455642.65 4367960.94 455646.92 4367965.7</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.001700600VJ56H_PI.3">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>456373.67 4367962.04</gml:lowerCorner>
         <gml:upperCorner>456384.46 4367971.69</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>001700600VJ56H_PI.3</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=001700600VJ56H&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=001700600VJ56H&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.001700600VJ56H_PI.3" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 456382.26 4367962.04 456373.67 4367966.26 456376.35 4367971.69 456378.71 4367970.53 456378.24 4367969.56 456384.46 4367966.5 456382.26 4367962.04</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.002000200VJ57A_PI.4">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454274.8645 4370359.706</gml:lowerCorner>
         <gml:upperCorner>454282.8785 4370365.1255</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2020-02-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>002000200VJ57A_PI.4</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=002000200VJ57A&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=002000200VJ57A&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.002000200VJ57A_PI.4" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454274.8645 4370360.8795 454275.544 4370365.1255 454282.8785 4370363.952 454282.199 4370359.706 454274.8645 4370360.8795</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.12265020000000_PI.5">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451054.92 4352851.79</gml:lowerCorner>
         <gml:upperCorner>451060.82 4352862.78</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-10-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>12265020000000_PI.5</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=12265020000000&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=12265020000000&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.12265020000000_PI.5" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 451055.8 4352862.78 451060.82 4352862.36 451059.94 4352851.79 451054.92 4352852.21 451055.8 4352862.78</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3400932VJ5730S_PI.6">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453424.16 4369938.28</gml:lowerCorner>
         <gml:upperCorner>453432.23 4369944.27</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-12-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3400932VJ5730S_PI.6</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3400932VJ5730S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3400932VJ5730S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3400932VJ5730S_PI.6" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453431.27 4369944.27 453432.23 4369939.82 453425.12 4369938.28 453424.16 4369942.73 453431.27 4369944.27</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3496227VJ5639N_PI.7">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453292.734483053 4369426.86633119</gml:lowerCorner>
         <gml:upperCorner>453299.944658435 4369434.50287657</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3496227VJ5639N_PI.7</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3496227VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3496227VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3496227VJ5639N_PI.7" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453292.734483053 4369429.35578194 453296.739968909 4369434.50287657 453299.944658435 4369432.01342582 453295.939172579 4369426.86633119 453292.734483053 4369429.35578194</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3496228VJ5639N_PI.8">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453335.150292891 4369395.46312438</gml:lowerCorner>
         <gml:upperCorner>453341.036219726 4369402.00690757</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3496228VJ5639N_PI.8</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3496228VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3496228VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3496228VJ5639N_PI.8" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453337.627817336 4369395.46312438 453335.150292891 4369397.24906184 453338.568509391 4369402.00690757 453341.036219726 4369400.2311526 453337.627817336 4369395.46312438</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3498245VJ5639N_PI.9">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453414.1419 4369593.57055</gml:lowerCorner>
         <gml:upperCorner>453419.8728 4369602.1024</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3498245VJ5639N_PI.9</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3498245VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3498245VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3498245VJ5639N_PI.9" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453415.9644 4369602.1024 453419.8728 4369601.16435 453418.05025 4369593.57055 453414.1419 4369594.50855 453415.9644 4369602.1024</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3590301VJ5639S_PI.10">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453453.14675 4368895.80625</gml:lowerCorner>
         <gml:upperCorner>453463.111 4368906.6075</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3590301VJ5639S_PI.10</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3590301VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3590301VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3590301VJ5639S_PI.10" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453453.14675 4368898.9021 453459.1122 4368906.6075 453463.111 4368903.51165 453457.14555 4368895.80625 453453.14675 4368898.9021</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3590311VJ5639S_PI.11">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453442.04 4368868.32</gml:lowerCorner>
         <gml:upperCorner>453447.07 4368874.26</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3590311VJ5639S_PI.11</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3590311VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3590311VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3590311VJ5639S_PI.11" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453445.04 4368874.26 453447.07 4368872.93 453444.07 4368868.32 453442.04 4368869.65 453445.04 4368874.26</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3597605VJ5639N_PI.12">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453484.772 4369508.626</gml:lowerCorner>
         <gml:upperCorner>453493.8165 4369517.1655</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2021-01-15T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3597605VJ5639N_PI.12</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3597605VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3597605VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3597605VJ5639N_PI.12" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="33"> 453484.986 4369510.2625 453484.7805 4369510.7985 453484.772 4369511.3725 453484.9605 4369511.9145 453485.298 4369512.3365 453486.195 4369513.2095 453487.618 4369514.31 453489.173 4369515.0035 453490.1895 4369515.374 453490.6625 4369515.452 453490.8925 4369516.284 453491.2145 4369516.735 453491.6755 4369517.042 453492.216 4369517.1655 453492.765 4369517.0895 453492.9285 4369517.025 453493.381 4369516.705 453493.6905 4369516.245 453493.8165 4369515.7055 453493.743 4369515.156 453493.479 4369514.6685 453493.0595 4369514.3065 453492.862 4369514.2345 453492.9635 4369513.8635 453493.0095 4369512.3175 453492.479 4369510.772 453491.648 4369509.3415 453490.7945 4369508.7415 453489.364 4369508.626 453487.5415 4369508.811 453486.665 4369509.157 453485.3625 4369509.8295 453484.986 4369510.2625</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3693006VJ5639S_PI.13">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453511.877761547 4369137.3528619</gml:lowerCorner>
         <gml:upperCorner>453517.713380359 4369141.31775532</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3693006VJ5639S_PI.13</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3693006VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3693006VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3693006VJ5639S_PI.13" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453511.877761547 4369137.83625357 453512.180986746 4369141.31775532 453517.713380359 4369140.83441185 453517.400155276 4369137.3528619 453511.877761547 4369137.83625357</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3693021VJ5639S_PI.14">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453494.431241996 4369118.99765249</gml:lowerCorner>
         <gml:upperCorner>453505.167430644 4369128.99811445</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3693021VJ5639S_PI.14</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3693021VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3693021VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3693021VJ5639S_PI.14" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453494.431241996 4369124.6220205 453497.760191045 4369128.99811445 453505.167430644 4369123.36374655 453501.838433403 4369118.99765249 453494.431241996 4369124.6220205</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3694819VJ5639S_PI.15">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453425.38 4369152.15</gml:lowerCorner>
         <gml:upperCorner>453435.2 4369160.54</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3694819VJ5639S_PI.15</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3694819VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3694819VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3694819VJ5639S_PI.15" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453425.38 4369157.02 453427.65 4369160.54 453435.2 4369155.68 453432.92 4369152.15 453425.38 4369157.02</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3697902VJ5639N_PI.16">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453541.968809789 4369528.135244</gml:lowerCorner>
         <gml:upperCorner>453550.601482185 4369536.94071124</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3697902VJ5639N_PI.16</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3697902VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3697902VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3697902VJ5639N_PI.16" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12"> 453544.045822183 4369536.94071124 453550.140024406 4369530.59701363 453549.876918531 4369530.34015706 453550.459665186 4369529.73310984 453550.601482185 4369529.05135626 453550.304172213 4369528.4448855 453549.440388594 4369528.135244 453548.873193874 4369528.37207759 453548.328882003 4369528.84865349 453547.984940652 4369528.52276341 453541.968809789 4369534.70551113 453544.045822183 4369536.94071124</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3700902VJ5730S_PI.17">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453660.26 4369831.31</gml:lowerCorner>
         <gml:upperCorner>453666.12 4369843.03</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2021-04-14T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3700902VJ5730S_PI.17</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3700902VJ5730S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3700902VJ5730S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3700902VJ5730S_PI.17" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19"> 453665.71 4369831.31 453661.03 4369831.51 453661.41 4369840.42 453661.05 4369840.47 453660.63 4369840.7 453660.35 4369841.09 453660.29 4369841.29 453660.26 4369841.55 453660.35 4369842.09 453660.62 4369842.56 453661.05 4369842.9 453661.54 4369843.03 453662.05 4369842.96 453662.49 4369842.7 453662.79 4369842.3 453662.92 4369841.8 453662.85 4369841.3 453666.12 4369841.16 453665.71 4369831.31</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3700902VJ5730S_PI.18">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453675.19 4369812.33</gml:lowerCorner>
         <gml:upperCorner>453681.1 4369822.9</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2021-04-14T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3700902VJ5730S_PI.18</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3700902VJ5730S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3700902VJ5730S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3700902VJ5730S_PI.18" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453675.94 4369822.9 453681.1 4369822.51 453680.35 4369812.33 453675.19 4369812.71 453675.94 4369822.9</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3700956VJ5730S_PI.19">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453515.21 4369807.46</gml:lowerCorner>
         <gml:upperCorner>453521.39 4369809.79</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-12-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3700956VJ5730S_PI.19</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3700956VJ5730S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3700956VJ5730S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3700956VJ5730S_PI.19" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453521.39 4369807.5 453515.25 4369807.46 453515.21 4369809.75 453521.39 4369809.79 453521.39 4369807.5</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3789009VJ5638N_PI.20">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453448.3425 4368709.136</gml:lowerCorner>
         <gml:upperCorner>453460.473 4368717.506</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-01-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3789009VJ5638N_PI.20</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3789009VJ5638N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3789009VJ5638N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3789009VJ5638N_PI.20" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453460.473 4368714.646 453458.9525 4368709.136 453448.3425 4368711.886 453449.9625 4368717.506 453460.473 4368714.646</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3791024VJ5639S_PI.21">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453561.96 4368875.8</gml:lowerCorner>
         <gml:upperCorner>453567.95 4368880.19</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-15T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3791024VJ5639S_PI.21</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3791024VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3791024VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3791024VJ5639S_PI.21" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12"> 453567.95 4368878.71 453567.36 4368876.74 453566.93 4368876.36 453566.55 4368876.13 453566.2 4368875.97 453565.87 4368875.87 453565.42 4368875.8 453564.72 4368875.83 453564.54 4368875.86 453561.96 4368876.64 453563.03 4368880.19 453567.95 4368878.71</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3793033VJ5639S_PI.22">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453578.062661032 4369081.56656854</gml:lowerCorner>
         <gml:upperCorner>453582.118810364 4369090.55796971</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3793033VJ5639S_PI.22</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3793033VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3793033VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3793033VJ5639S_PI.22" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18"> 453578.062661032 4369090.4848665 453581.952603952 4369090.55796971 453582.118810364 4369082.77809983 453581.338826567 4369082.75747759 453581.3090659 4369082.45745376 453581.199289304 4369082.17736609 453581.019488798 4369081.92722258 453580.779640446 4369081.73703118 453580.499736265 4369081.61680785 453580.199776247 4369081.56656854 453579.889744436 4369081.60632123 453579.609656773 4369081.71609782 453579.359513258 4369081.89589833 453579.16932186 4369082.13574668 453579.049098529 4369082.41565086 453579.008859218 4369082.71561886 453578.228875421 4369082.69499662 453578.062661032 4369090.4848665</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3798113VJ5639N_PI.23">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453636.80051804 4369566.9265286</gml:lowerCorner>
         <gml:upperCorner>453644.194063039 4369577.84240333</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3798113VJ5639N_PI.23</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3798113VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3798113VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3798113VJ5639N_PI.23" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453640.849383855 4369566.9265286 453636.80051804 4369568.35841044 453640.145197224 4369577.84240333 453644.194063039 4369576.41052149 453640.849383855 4369566.9265286</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3892710VJ5639S_PI.24">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453689.179472597 4368990.39529782</gml:lowerCorner>
         <gml:upperCorner>453693.048916802 4368994.45105916</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3892710VJ5639S_PI.24</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3892710VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3892710VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3892710VJ5639S_PI.24" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8"> 453693.048916802 4368993.21619036 453692.45396702 4368990.39529782 453689.179472597 4368990.76743526 453689.857093353 4368993.1269543 453689.983918569 4368993.55499094 453690.238205316 4368994.45105916 453692.363617406 4368993.51713012 453693.048916802 4368993.21619036</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3893713VJ5639S_PI.25">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453674.141346432 4369104.80339121</gml:lowerCorner>
         <gml:upperCorner>453680.05571452 4369110.11412937</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3893713VJ5639S_PI.25</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3893713VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3893713VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3893713VJ5639S_PI.25" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453679.349066985 4369104.80339121 453674.141346432 4369105.72456469 453674.471657581 4369110.11412937 453680.05571452 4369108.79841315 453679.349066985 4369104.80339121</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3897801VJ5639N_PI.26">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453604.71 4369521.83</gml:lowerCorner>
         <gml:upperCorner>453613.08 4369535.92</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3897801VJ5639N_PI.26</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3897801VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3897801VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3897801VJ5639N_PI.26" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453604.71 4369522.66 453606.38 4369535.92 453613.08 4369535.09 453611.41 4369521.83 453604.71 4369522.66</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3897806VJ5639N_PI.27">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453635.28 4369494.1725</gml:lowerCorner>
         <gml:upperCorner>453642.905 4369499.847</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-03-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3897806VJ5639N_PI.27</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3897806VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3897806VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3897806VJ5639N_PI.27" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 453636.108 4369499.847 453642.905 4369497.742 453641.8 4369494.1725 453640.814 4369494.478 453641.0915 4369495.3735 453635.28 4369497.173 453636.108 4369499.847</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3897810VJ5639N_PI.28">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453702.43825 4369528.6881</gml:lowerCorner>
         <gml:upperCorner>453709.52335 4369537.30785</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3897810VJ5639N_PI.28</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3897810VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3897810VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3897810VJ5639N_PI.28" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15"> 453706.45065 4369536.53515 453706.60915 4369536.76165 453707.05945 4369537.12245 453707.60585 4369537.30785 453708.1827 4369537.2956 453708.72075 4369537.0872 453708.7383 4369537.0764 453709.16815 4369536.6915 453709.44075 4369536.18295 453709.52335 4369535.6119 453709.40605 4369535.0469 453709.1933 4369534.7067 453705.1809 4369528.6881 453702.43825 4369530.51655 453706.45065 4369536.53515</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3897831VJ5639N_PI.29">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453596.43 4369544.62</gml:lowerCorner>
         <gml:upperCorner>453605.89 4369549.36</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2013-11-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3897831VJ5639N_PI.29</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3897831VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3897831VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3897831VJ5639N_PI.29" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="21"> 453596.43 4369545.61 453596.92 4369549.36 453604.58 4369548.38 453604.51 4369547.93 453604.91 4369547.86 453605.18 4369547.74 453605.42 4369547.56 453605.62 4369547.34 453605.77 4369547.09 453605.86 4369546.8 453605.89 4369546.5 453605.85 4369546.21 453605.75 4369545.92 453605.59 4369545.67 453605.38 4369545.46 453605.14 4369545.29 453604.86 4369545.19 453604.56 4369545.14 453604.16 4369545.17 453604.1 4369544.62 453596.43 4369545.61</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3898209VJ5639N_PI.30">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453704.7125 4369598.273</gml:lowerCorner>
         <gml:upperCorner>453712.227 4369606.8365</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-01-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3898209VJ5639N_PI.30</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3898209VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3898209VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3898209VJ5639N_PI.30" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 453704.7125 4369599.868 453707.3155 4369606.8365 453712.227 4369604.4855 453711.513 4369602.177 453709.75 4369603.0165 453707.903 4369598.273 453704.7125 4369599.868</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3901102VJ5730S_PI.31">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453785.4427 4369969.40725</gml:lowerCorner>
         <gml:upperCorner>453797.5828 4369975.71505</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3901102VJ5730S_PI.31</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3901102VJ5730S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3901102VJ5730S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3901102VJ5730S_PI.31" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453785.4427 4369975.14995 453797.30935 4369975.71505 453797.5828 4369969.97235 453785.71615 4369969.40725 453785.4427 4369975.14995</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3901114VJ5730S_PI.32">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453809.2981 4369812.50935</gml:lowerCorner>
         <gml:upperCorner>453816.48135 4369817.8871</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3901114VJ5730S_PI.32</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3901114VJ5730S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3901114VJ5730S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3901114VJ5730S_PI.32" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="6"> 453809.2981 4369817.8871 453809.926 4369817.8255 453816.48135 4369816.9774 453816.48135 4369812.50935 453809.2981 4369813.27355 453809.2981 4369817.8871</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3988007VJ5638N_PI.33">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453866.77615289 4368559.35675384</gml:lowerCorner>
         <gml:upperCorner>453873.495752033 4368570.27710413</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3988007VJ5638N_PI.33</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3988007VJ5638N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3988007VJ5638N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3988007VJ5638N_PI.33" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19"> 453871.722312292 4368570.27710413 453872.041590472 4368570.1942703 453872.340160195 4368570.03161692 453872.469179877 4368569.92046873 453872.676777927 4368569.64861757 453872.804024499 4368569.33747723 453872.832604833 4368569.17721756 453872.829590548 4368568.83723092 453872.777730749 4368568.62768245 453873.495752033 4368568.4013079 453870.585452767 4368559.35675384 453866.77615289 4368560.58057345 453869.686452156 4368569.62512751 453870.384474226 4368569.39893028 453870.456244584 4368569.59830183 453870.648719469 4368569.87660637 453870.910571016 4368570.08429308 453871.211889057 4368570.23162752 453871.722312292 4368570.27710413</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3988009VJ5638N_PI.34">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453903.865600376 4368526.25357542</gml:lowerCorner>
         <gml:upperCorner>453909.741363588 4368535.12784521</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3988009VJ5638N_PI.34</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3988009VJ5638N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3988009VJ5638N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3988009VJ5638N_PI.34" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13"> 453903.865600376 4368528.06027728 453906.765572179 4368535.12784521 453909.741363588 4368533.90676521 453906.841442227 4368526.83924684 453906.635171705 4368526.71377061 453906.173507104 4368526.3927009 453905.628702271 4368526.25357542 453905.069664969 4368526.31388396 453904.771335281 4368526.43593362 453904.330360902 4368526.7848068 453904.039415552 4368527.2660051 453903.935260072 4368527.81855021 453903.865600376 4368528.06027728</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3991023VJ5639S_PI.35">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453775.712575172 4368905.47752854</gml:lowerCorner>
         <gml:upperCorner>453781.263375172 4368913.46762854</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3991023VJ5639S_PI.35</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3991023VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3991023VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3991023VJ5639S_PI.35" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453779.340475172 4368913.46762854 453781.263375172 4368906.47517854 453777.635525172 4368905.47752854 453775.712575172 4368912.46997854 453779.340475172 4368913.46762854</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3991033VJ5639S_PI.36">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453769.825375172 4368894.25922854</gml:lowerCorner>
         <gml:upperCorner>453783.155375172 4368903.09922854</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3991033VJ5639S_PI.36</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3991033VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3991033VJ5639S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3991033VJ5639S_PI.36" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453783.155375172 4368897.41922854 453771.345375172 4368894.25922854 453769.825375172 4368899.93922854 453781.635375172 4368903.09922854 453783.155375172 4368897.41922854</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3995208VJ5639N_PI.37">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453835.579478468 4369262.39134048</gml:lowerCorner>
         <gml:upperCorner>453839.828752342 4369266.53960199</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3995208VJ5639N_PI.37</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3995208VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3995208VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3995208VJ5639N_PI.37" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453838.437802716 4369262.39134048 453835.579478468 4369264.51713033 453836.950648912 4369266.53960199 453839.828752342 4369264.37370249 453838.437802716 4369262.39134048</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3996102VJ5639N_PI.38">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453823.1435 4369422.691</gml:lowerCorner>
         <gml:upperCorner>453830.524 4369430.753</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-08-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3996102VJ5639N_PI.38</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3996102VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3996102VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3996102VJ5639N_PI.38" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453830.524 4369428.366 453826.5995 4369422.691 453823.1435 4369425.0775 453827.0675 4369430.753 453830.524 4369428.366</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3998412VJ5639N_PI.39">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453862.16 4369645.04</gml:lowerCorner>
         <gml:upperCorner>453872.35 4369651.37</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-06-07T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3998412VJ5639N_PI.39</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3998412VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3998412VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3998412VJ5639N_PI.39" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13"> 453862.5 4369651.37 453872.35 4369649.64 453871.83 4369646.68 453871.67 4369646.18 453871.39 4369645.74 453871.01 4369645.39 453870.55 4369645.15 453870.04 4369645.04 453869.51 4369645.06 453862.62 4369646.28 453863.14 4369649.23 453862.16 4369649.4 453862.5 4369651.37</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3998421VJ5639N_PI.40">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453886.623 4369582.7425</gml:lowerCorner>
         <gml:upperCorner>453892.641 4369593.168</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2026-07-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3998421VJ5639N_PI.40</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3998421VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3998421VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3998421VJ5639N_PI.40" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18"> 453888.4165 4369593.168 453892.641 4369592.1255 453891.0165 4369584.7645 453891.14 4369584.745 453891.516 4369584.4875 453891.7455 4369584.094 453891.784 4369583.64 453891.625 4369583.213 453891.298 4369582.8955 453890.8665 4369582.7485 453890.7755 4369582.7425 453890.329 4369582.834 453889.9645 4369583.108 453889.753 4369583.511 453889.734 4369583.9665 453889.852 4369584.244 453886.623 4369585.041 453888.4165 4369593.168</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.3998422VJ5639N_PI.41">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453818.79 4369660.43</gml:lowerCorner>
         <gml:upperCorner>453827.2 4369665.73</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>3998422VJ5639N_PI.41</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=3998422VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=3998422VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.3998422VJ5639N_PI.41" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453818.79 4369662.42 453819.67 4369665.73 453827.2 4369663.74 453826.32 4369660.43 453818.79 4369662.42</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4089020VJ5648N_PI.42">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453883.93201913 4368643.97908585</gml:lowerCorner>
         <gml:upperCorner>453890.653464916 4368655.26749455</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4089020VJ5648N_PI.42</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4089020VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4089020VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4089020VJ5648N_PI.42" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13"> 453883.93201913 4368644.80802982 453886.245933648 4368654.33432499 453886.852378005 4368654.84854794 453887.460280396 4368655.15277595 453888.139500274 4368655.26749455 453888.810108996 4368655.18214854 453889.060727842 4368655.09388647 453889.653143679 4368654.74799128 453890.116604101 4368654.25119712 453890.410901783 4368653.63322554 453890.653464916 4368653.26490079 453888.407882386 4368643.97908585 453883.93201913 4368644.80802982</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4091016VJ5649S_PI.43">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453851.633513304 4368864.7887053</gml:lowerCorner>
         <gml:upperCorner>453855.37180043 4368866.77011421</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4091016VJ5649S_PI.43</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4091016VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4091016VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4091016VJ5649S_PI.43" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453851.633513304 4368866.38766747 453855.201678763 4368866.77011421 453855.37180043 4368865.16115224 453851.803572083 4368864.7887053 453851.633513304 4368866.38766747</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4097508VJ5649N_PI.44">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453881.52 4369452.79</gml:lowerCorner>
         <gml:upperCorner>453891.36 4369459.05</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4097508VJ5649N_PI.44</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4097508VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4097508VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4097508VJ5649N_PI.44" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15"> 453881.67 4369457.74 453882.01 4369458.19 453882.49 4369458.5 453883.04 4369458.62 453883.46 4369458.57 453883.58 4369459.05 453891.36 4369457.05 453890.26 4369452.79 453882.49 4369454.79 453882.67 4369455.5 453882.05 4369455.82 453881.69 4369456.26 453881.52 4369456.8 453881.54 4369457.37 453881.67 4369457.74</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4097510VJ5639N_PI.45">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453899.1855 4369416.808</gml:lowerCorner>
         <gml:upperCorner>453902.96 4369422.43</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2021-11-23T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4097510VJ5639N_PI.45</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4097510VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4097510VJ5639N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4097510VJ5639N_PI.45" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453901.7595 4369416.808 453899.1855 4369417.429 453900.4395 4369422.43 453902.96 4369421.82 453901.7595 4369416.808</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4097818VJ5649N_PI.46">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453865.963 4369549.1415</gml:lowerCorner>
         <gml:upperCorner>453870.731 4369555.1005</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-03-17T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4097818VJ5649N_PI.46</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4097818VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4097818VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4097818VJ5649N_PI.46" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 453868.4025 4369555.1005 453870.512 4369554.406 453870.705 4369554.2565 453870.731 4369554.187 453870.7 4369553.9675 453868.3495 4369549.2355 453868.1305 4369549.1415 453865.963 4369550.0405 453868.4025 4369555.1005</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4188006VJ5648N_PI.47">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453989.924545526 4368653.32178529</gml:lowerCorner>
         <gml:upperCorner>453993.246621462 4368658.68568486</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4188006VJ5648N_PI.47</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4188006VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4188006VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4188006VJ5648N_PI.47" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="34"> 453991.198477869 4368658.65311666 453991.56826066 4368658.68568486 453992.389421209 4368658.52138223 453992.901283532 4368658.25492968 453993.133013743 4368658.0065326 453993.214678139 4368657.76709383 453993.246621462 4368657.48730887 453993.178983776 4368657.14683105 453992.961905146 4368656.72531371 453992.545109059 4368656.26240873 453992.067897836 4368655.85908572 453992.00032958 4368655.50860814 453992.081299675 4368655.36916696 453992.202060515 4368655.26000277 453992.934403546 4368654.92507937 453993.075649915 4368654.74605573 453993.177244399 4368654.51675558 453993.22946496 4368654.19711044 453993.181687932 4368653.87677101 453993.043913073 4368653.5558067 453992.844959346 4368653.40442171 453992.465523947 4368653.32178529 453991.74512472 4368653.37678487 453991.1341674 4368653.51254625 453990.762718284 4368653.71997227 453990.35043697 4368654.04711768 453990.078221711 4368654.36523535 453989.966349747 4368654.63446511 453989.924545526 4368654.89418112 453989.950795573 4368655.4343764 453990.614740807 4368657.74904197 453990.870360438 4368658.38083197 453991.00924618 4368658.54180014 453991.198477869 4368658.65311666</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4188502VJ5648N_PI.48">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453945.299486876 4368553.72467034</gml:lowerCorner>
         <gml:upperCorner>453952.917268016 4368559.66024054</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4188502VJ5648N_PI.48</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4188502VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4188502VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4188502VJ5648N_PI.48" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453946.564988302 4368559.66024054 453952.917268016 4368557.56933065 453951.651766589 4368553.72467034 453945.299486876 4368555.81558024 453946.564988302 4368559.66024054</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4193606VJ5649S_PI.49">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453959.848649509 4369045.72547399</gml:lowerCorner>
         <gml:upperCorner>453969.148649509 4369056.47547399</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4193606VJ5649S_PI.49</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4193606VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4193606VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4193606VJ5649S_PI.49" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453964.758649509 4369045.72547399 453959.848649509 4369048.39547399 453964.238649509 4369056.47547399 453969.148649509 4369053.80547399 453964.758649509 4369045.72547399</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4195003VJ5649N_PI.50">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453993.619413087 4369284.26251925</gml:lowerCorner>
         <gml:upperCorner>454000.586569736 4369290.5534893</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4195003VJ5649N_PI.50</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4195003VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4195003VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4195003VJ5649N_PI.50" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453993.619413087 4369288.00225559 453995.494221491 4369290.5534893 454000.586569736 4369286.82381246 453998.701821187 4369284.26251925 453993.619413087 4369288.00225559</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4201001VJ5740S_PI.51">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454073.001037233 4369936.08187589</gml:lowerCorner>
         <gml:upperCorner>454081.685017951 4369939.82019077</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4201001VJ5740S_PI.51</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4201001VJ5740S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4201001VJ5740S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4201001VJ5740S_PI.51" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12"> 454073.015261267 4369937.85942416 454073.001037233 4369938.4293344 454073.177030312 4369938.97065356 454073.533685445 4369939.42330919 454074.031448393 4369939.72700649 454074.460769588 4369939.82019077 454081.685017951 4369939.27371517 454081.448666401 4369936.08187589 454074.134346399 4369936.63768423 454073.612433801 4369936.89382333 454073.229257477 4369937.32099532 454073.015261267 4369937.85942416</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4201023VJ5740S_PI.52">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454169.18 4369975.99</gml:lowerCorner>
         <gml:upperCorner>454174.9 4369980.26</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-09-03T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4201023VJ5740S_PI.52</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4201023VJ5740S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4201023VJ5740S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4201023VJ5740S_PI.52" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="6"> 454174.9 4369978.82 454173.91 4369975.99 454169.18 4369977.64 454169.96 4369979.77 454170.75 4369980.26 454174.9 4369978.82</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4286909VJ5648N_PI.53">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454121.9 4368435.14</gml:lowerCorner>
         <gml:upperCorner>454128.21 4368444</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-06-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4286909VJ5648N_PI.53</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4286909VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4286909VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4286909VJ5648N_PI.53" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454125.7 4368435.14 454121.9 4368436.4 454124.41 4368444 454128.21 4368442.74 454125.7 4368435.14</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4286911VJ5648N_PI.54">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454128.21 4368455.26</gml:lowerCorner>
         <gml:upperCorner>454134.52 4368464.11</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-06-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4286911VJ5648N_PI.54</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4286911VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4286911VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4286911VJ5648N_PI.54" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454134.52 4368462.85 454132 4368455.26 454128.21 4368456.51 454130.72 4368464.11 454134.52 4368462.85</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4289245VJ5648N_PI.55">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454149.84588784 4368775.4404798</gml:lowerCorner>
         <gml:upperCorner>454153.18250838 4368778.51894322</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4289245VJ5648N_PI.55</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4289245VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4289245VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4289245VJ5648N_PI.55" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454150.193909566 4368775.4404798 454149.84588784 4368777.82068639 454152.592788254 4368778.51894322 454153.18250838 4368776.38657355 454150.193909566 4368775.4404798</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4292311VJ5649S_PI.56">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454183.372596995 4368960.24788149</gml:lowerCorner>
         <gml:upperCorner>454190.002596995 4368966.51788149</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4292311VJ5649S_PI.56</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4292311VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4292311VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4292311VJ5649S_PI.56" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="20"> 454183.372596995 4368965.21788149 454184.902596995 4368966.51788149 454186.532596995 4368964.60788149 454188.052596995 4368965.89788149 454190.002596995 4368963.61788149 454188.392596995 4368962.25788149 454188.662596995 4368962.11788149 454188.872596995 4368961.90788149 454188.952596995 4368961.78788149 454189.062596995 4368961.50788149 454189.062596995 4368961.06788149 454188.962596995 4368960.78788149 454188.792596995 4368960.54788149 454188.552596995 4368960.36788149 454188.422596995 4368960.30788149 454188.132596995 4368960.24788149 454187.832596995 4368960.26788149 454187.692596995 4368960.30788149 454187.322596995 4368960.53788149 454183.372596995 4368965.21788149</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4292326VJ5649S_PI.57">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454116.442096995 4368990.41588149</gml:lowerCorner>
         <gml:upperCorner>454119.312096995 4368993.12588149</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4292326VJ5649S_PI.57</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4292326VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4292326VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4292326VJ5649S_PI.57" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454116.442096995 4368991.75588149 454117.242096995 4368993.12588149 454119.312096995 4368992.15588149 454118.852096995 4368990.41588149 454116.442096995 4368991.75588149</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4292329VJ5649S_PI.58">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454107.822096995 4368999.10588149</gml:lowerCorner>
         <gml:upperCorner>454113.232096995 4369004.18588149</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4292329VJ5649S_PI.58</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4292329VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4292329VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4292329VJ5649S_PI.58" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="6"> 454109.922096995 4369004.18588149 454113.232096995 4369001.99588149 454111.292096995 4368999.10588149 454110.102096995 4368999.89588149 454107.822096995 4369001.41588149 454109.922096995 4369004.18588149</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4296308VJ5649N_PI.59">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454112.1005 4369448.09</gml:lowerCorner>
         <gml:upperCorner>454119.1815 4369456.0555</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-10-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4296308VJ5649N_PI.59</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4296308VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4296308VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4296308VJ5649N_PI.59" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454119.1815 4369453.8995 454115.543 4369448.09 454112.1005 4369450.246 454115.739 4369456.0555 454119.1815 4369453.8995</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4298528VJ5649N_PI.60">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454103.14 4369552.37</gml:lowerCorner>
         <gml:upperCorner>454111.75 4369558.1125</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-04-23T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4298528VJ5649N_PI.60</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4298528VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4298528VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4298528VJ5649N_PI.60" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454110.6515 4369558.1125 454111.75 4369554.94 454104.3 4369552.37 454103.14 4369555.72 454110.6515 4369558.1125</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4386002VJ5648N_PI.61">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454208.18 4368465.92</gml:lowerCorner>
         <gml:upperCorner>454213.38 4368473.52</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-05-17T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4386002VJ5648N_PI.61</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4386002VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4386002VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4386002VJ5648N_PI.61" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454213.38 4368472.54 454211.02 4368465.92 454208.18 4368466.9 454210.49 4368473.52 454213.38 4368472.54</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4388017VJ5648N_PI.62">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454187.85 4368602.71</gml:lowerCorner>
         <gml:upperCorner>454197.39 4368607.59</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-03-07T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4388017VJ5648N_PI.62</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4388017VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4388017VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4388017VJ5648N_PI.62" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454187.85 4368607.59 454197.34 4368607.44 454197.39 4368602.71 454187.89 4368602.81 454187.85 4368607.59</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4395609VJ5649N_PI.63">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454161.513625616 4369264.16792193</gml:lowerCorner>
         <gml:upperCorner>454167.250169926 4369268.63540012</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4395609VJ5649N_PI.63</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4395609VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4395609VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4395609VJ5649N_PI.63" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454162.39847364 4369268.63540012 454167.250169926 4369267.23531329 454166.365404266 4369264.16792193 454161.513625616 4369265.57800843 454162.39847364 4369268.63540012</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4397009VJ5649N_PI.64">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454252.49 4369469.68</gml:lowerCorner>
         <gml:upperCorner>454263.12 4369477.4</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2013-11-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4397009VJ5649N_PI.64</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4397009VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4397009VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4397009VJ5649N_PI.64" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454261.54 4369469.68 454252.49 4369472.98 454254.02 4369477.4 454263.12 4369474.28 454261.54 4369469.68</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.44020A0VJ5740S_PI.65">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454141.32915 4369738.3609</gml:lowerCorner>
         <gml:upperCorner>454149.85625 4369744.40835</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-11-04T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>44020A0VJ5740S_PI.65</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=44020A0VJ5740S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=44020A0VJ5740S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.44020A0VJ5740S_PI.65" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16"> 454143.0728 4369743.9352 454143.2524 4369744.40835 454149.85625 4369741.90175 454148.5123 4369738.3609 454141.9084 4369740.8675 454142.2006 4369741.63725 454141.74085 4369741.8957 454141.44445 4369742.2921 454141.32915 4369742.77345 454141.41375 4369743.26115 454141.46195 4369743.3682 454141.68445 4369743.67555 454142.097 4369743.949 454142.5841 4369744.03685 454142.9371 4369743.97565 454143.0728 4369743.9352</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4402083VJ5640S_PI.66">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454370.73 4370392.92</gml:lowerCorner>
         <gml:upperCorner>454381.93 4370397.75</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-06-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4402083VJ5640S_PI.66</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4402083VJ5640S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4402083VJ5640S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4402083VJ5640S_PI.66" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13"> 454370.73 4370394.16 454371.2 4370397.75 454380.52 4370396.51 454380.43 4370395.84 454381.14 4370395.79 454381.56 4370395.58 454381.93 4370395.1 454381.93 4370394.55 454381.59 4370394.06 454381.09 4370393.77 454380.15 4370393.8 454380.04 4370392.92 454370.73 4370394.16</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4487101VJ5648N_PI.67">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454245.151205607 4368563.73846998</gml:lowerCorner>
         <gml:upperCorner>454249.931205607 4368570.27846998</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4487101VJ5648N_PI.67</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4487101VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4487101VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4487101VJ5648N_PI.67" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="6"> 454245.511205607 4368564.08846998 454245.151205607 4368570.27846998 454249.871205607 4368569.96896998 454249.931205607 4368565.62846998 454248.211205607 4368563.73846998 454245.511205607 4368564.08846998</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4494017VJ5649S_PI.68">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454267.044207744 4369214.36645213</gml:lowerCorner>
         <gml:upperCorner>454272.592357744 4369222.29575213</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4494017VJ5649S_PI.68</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4494017VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4494017VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4494017VJ5649S_PI.68" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="31"> 454268.304907744 4369220.82345213 454268.617757744 4369221.40960213 454269.090907744 4369221.87615213 454269.681407744 4369222.18070213 454270.335807744 4369222.29575213 454270.643057744 4369222.28140213 454270.994807744 4369222.21090213 454271.598657744 4369221.93375213 454272.092707744 4369221.48945213 454272.432157744 4369220.91825213 454272.586257744 4369220.27195213 454272.592357744 4369220.00725213 454272.537657744 4369218.83170213 454272.290157744 4369217.41205213 454271.848457744 4369216.04035213 454271.221057744 4369214.74300213 454270.994857744 4369214.36645213 454270.084057744 4369214.41260213 454269.205257744 4369214.65620213 454268.708307744 4369214.89415213 454268.400657744 4369215.08550213 454267.709007744 4369215.67985213 454267.163557744 4369216.41065213 454267.125307744 4369216.47710213 454267.044207744 4369216.78015213 454267.124557744 4369217.16005213 454267.383307744 4369217.44955213 454267.751857744 4369217.57185213 454268.132357744 4369217.49450213 454268.423907744 4369217.23800213 454268.304907744 4369220.82345213</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4498031VJ5649N_PI.69">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454238.34 4369634.71</gml:lowerCorner>
         <gml:upperCorner>454242.71 4369640.25</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-15T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4498031VJ5649N_PI.69</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4498031VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4498031VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4498031VJ5649N_PI.69" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454238.34 4369635.75 454240.27 4369640.25 454242.71 4369639.2 454240.78 4369634.71 454238.34 4369635.75</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4500026VJ5740S_PI.70">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454361.23 4369795.3</gml:lowerCorner>
         <gml:upperCorner>454367.17 4369802.78</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4500026VJ5740S_PI.70</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4500026VJ5740S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4500026VJ5740S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4500026VJ5740S_PI.70" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454364.2 4369795.3 454361.23 4369796.77 454364.2 4369802.78 454367.17 4369801.31 454364.2 4369795.3</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A00800349_PI.71">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>457015.86 4373424.16</gml:lowerCorner>
         <gml:upperCorner>457020.94 4373431.88</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A00800349_PI.71</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A00800349&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A00800349&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A00800349_PI.71" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 457017.17 4373431.88 457020.94 4373431.16 457019.59 4373424.16 457015.86 4373424.88 457017.17 4373431.88</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A00800455_PI.72">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>456493.39 4372257.41</gml:lowerCorner>
         <gml:upperCorner>456500.79 4372266.16</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A00800455_PI.72</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A00800455&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A00800455&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A00800455_PI.72" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 456497.86 4372257.41 456493.39 4372263.39 456493.39 4372265.37 456494.18 4372266.16 456496.43 4372265.77 456500.79 4372259.43 456497.86 4372257.41</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A01100153_PI.73">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>463779.27 4373819.38</gml:lowerCorner>
         <gml:upperCorner>463788.32 4373825.89</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A01100153_PI.73</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A01100153&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A01100153&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A01100153_PI.73" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 463788.32 4373821.65 463780.5 4373819.38 463779.27 4373823.63 463787.08 4373825.89 463788.32 4373821.65</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A01800261_PI.74">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>457496.18 4367208.26</gml:lowerCorner>
         <gml:upperCorner>457510.33 4367221.69</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2020-04-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A01800261_PI.74</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A01800261&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A01800261&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A01800261_PI.74" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 457496.18 4367217.13 457500.3 4367221.69 457510.33 4367212.61 457506.39 4367208.26 457496.18 4367217.13</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A03200058_PI.75">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451350.697 4352813.05</gml:lowerCorner>
         <gml:upperCorner>451355.088 4352820.1115</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-04-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A03200058_PI.75</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A03200058&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A03200058&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A03200058_PI.75" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 451354.68 4352820.1115 451355.088 4352813.333 451351.141 4352813.05 451350.697 4352819.87 451354.68 4352820.1115</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A03300018_PI.76">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451868.88 4352381.84</gml:lowerCorner>
         <gml:upperCorner>451877.5 4352389.71</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-10-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A03300018_PI.76</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A03300018&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A03300018&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A03300018_PI.76" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 451868.88 4352385.58 451874.95 4352389.71 451877.5 4352385.96 451871.42 4352381.84 451868.88 4352385.58</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A03300046_PI.77">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451679.35 4352492.87</gml:lowerCorner>
         <gml:upperCorner>451682.73 4352500.09</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-12-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A03300046_PI.77</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A03300046&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A03300046&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A03300046_PI.77" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 451679.35 4352493.2 451680.3 4352500.09 451682.73 4352499.76 451681.79 4352492.87 451679.35 4352493.2</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A03300081_PI.78">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452033.16 4352424.72</gml:lowerCorner>
         <gml:upperCorner>452044.69 4352431.27</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A03300081_PI.78</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A03300081&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A03300081&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A03300081_PI.78" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16"> 452033.27 4352429.88 452033.58 4352430.38 452034.03 4352430.76 452034.59 4352430.95 452035.28 4352430.93 452035.36 4352431.27 452044.69 4352429.24 452043.71 4352424.72 452034.37 4352426.75 452034.55 4352427.58 452034.13 4352427.7 452033.65 4352428.04 452033.31 4352428.52 452033.16 4352429.09 452033.21 4352429.68 452033.27 4352429.88</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A03300100_PI.79">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451930.87 4352501.67</gml:lowerCorner>
         <gml:upperCorner>451935.76 4352509.81</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-04-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A03300100_PI.79</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A03300100&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A03300100&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A03300100_PI.79" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13"> 451935.76 4352509.18 451934.64 4352502.47 451934.29 4352502.53 451933.86 4352502.01 451933.33 4352501.74 451932.74 4352501.67 451932.45 4352501.71 451931.91 4352501.93 451931.46 4352502.33 451931.21 4352503.04 451930.87 4352503.1 451931.99 4352509.81 451935.76 4352509.18</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A03300104_PI.80">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451378.26 4352648.21</gml:lowerCorner>
         <gml:upperCorner>451381.93 4352657.62</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-06-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A03300104_PI.80</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A03300104&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A03300104&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A03300104_PI.80" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 451378.26 4352657.62 451381.93 4352657.62 451381.93 4352648.21 451378.26 4352648.21 451378.26 4352657.62</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A03300108_PI.81">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451659.23 4352574.39</gml:lowerCorner>
         <gml:upperCorner>451666.58 4352578.95</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-09-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A03300108_PI.81</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A03300108&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A03300108&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A03300108_PI.81" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 451666.58 4352577.91 451666.04 4352574.39 451659.23 4352575.44 451659.77 4352578.95 451666.58 4352577.91</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A03300114_PI.82">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451702.82 4352644.84</gml:lowerCorner>
         <gml:upperCorner>451707.15 4352653.27</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-09-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A03300114_PI.82</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A03300114&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A03300114&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A03300114_PI.82" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14"> 451703.66 4352653.27 451707.15 4352652.85 451706.31 4352645.92 451705.79 4352645.98 451705.68 4352645.49 451705.38 4352645.1 451704.95 4352644.87 451704.39 4352644.84 451703.94 4352645.03 451703.6 4352645.38 451703.44 4352645.84 451703.47 4352646.26 451702.82 4352646.34 451703.66 4352653.27</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A03300115_PI.83">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451720.76 4352626.25</gml:lowerCorner>
         <gml:upperCorner>451725.63 4352628.91</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-09-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A03300115_PI.83</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A03300115&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A03300115&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A03300115_PI.83" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8"> 451720.76 4352628.35 451722.64 4352628.91 451723.31 4352628.13 451725.63 4352627.91 451725.63 4352626.25 451721.98 4352626.25 451720.76 4352627.36 451720.76 4352628.35</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A03300120_PI.84">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451524.5 4352564.26</gml:lowerCorner>
         <gml:upperCorner>451527.92 4352573.36</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-09-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A03300120_PI.84</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A03300120&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A03300120&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A03300120_PI.84" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11"> 451526.43 4352564.26 451525.89 4352564.29 451525.44 4352564.49 451525.05 4352564.87 451524.5 4352565.68 451524.5 4352573.36 451527.92 4352573.36 451527.92 4352565.68 451527.37 4352564.77 451526.95 4352564.43 451526.43 4352564.26</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A03501029_PI.85">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451344.54 4356507.18</gml:lowerCorner>
         <gml:upperCorner>451350.67 4356515.15</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A03501029_PI.85</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A03501029&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A03501029&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A03501029_PI.85" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="21"> 451349.88 4356514.82 451350.04 4356514.7 451350.31 4356514.4 451350.59 4356513.86 451350.67 4356513.26 451350.55 4356512.66 451347.94 4356507.51 451347.33 4356507.25 451346.66 4356507.18 451346.01 4356507.31 451345.6 4356507.51 451345.42 4356507.63 451344.96 4356508.11 451344.65 4356508.71 451344.54 4356509.37 451344.55 4356509.61 451347.62 4356514.7 451348.13 4356515.02 451348.73 4356515.15 451349.33 4356515.08 451349.88 4356514.82</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A04000026_PI.86">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451667.41 4368626.4</gml:lowerCorner>
         <gml:upperCorner>451675.12 4368636.35</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A04000026_PI.86</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A04000026&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A04000026&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A04000026_PI.86" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 451667.41 4368628.22 451671.21 4368636.35 451675.12 4368634.52 451671.32 4368626.4 451667.41 4368628.22</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A04000034_PI.87">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451001.43 4368400.18</gml:lowerCorner>
         <gml:upperCorner>451009.21 4368407.37</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-01-17T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A04000034_PI.87</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A04000034&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A04000034&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A04000034_PI.87" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14"> 451009.21 4368402.72 451006.94 4368400.18 451001.92 4368404.23 451001.58 4368404.74 451001.43 4368405.33 451001.47 4368405.94 451001.71 4368406.5 451001.92 4368406.78 451002.11 4368406.96 451002.64 4368407.26 451003.25 4368407.37 451003.85 4368407.28 451004.39 4368407.01 451009.21 4368402.72</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A04000061_PI.88">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451941.84 4368825.87</gml:lowerCorner>
         <gml:upperCorner>451950.2 4368832.3</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-05-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A04000061_PI.88</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A04000061&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A04000061&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A04000061_PI.88" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 451943.3 4368832.3 451950.2 4368829.54 451948.73 4368825.87 451941.84 4368828.63 451943.3 4368832.3</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A04000066_PI.89">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452180.29 4368773.15</gml:lowerCorner>
         <gml:upperCorner>452188.93 4368779.25</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-15T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A04000066_PI.89</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A04000066&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A04000066&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A04000066_PI.89" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16"> 452180.53 4368778.36 452180.79 4368778.59 452181.05 4368778.7 452181.34 4368778.73 452181.73 4368778.65 452181.99 4368779.25 452188.93 4368776.25 452187.59 4368773.15 452180.65 4368776.15 452180.91 4368776.76 452180.7 4368776.88 452180.52 4368777.05 452180.35 4368777.35 452180.29 4368777.77 452180.36 4368778.09 452180.53 4368778.36</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A04000131_PI.90">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452355.95 4368608.22</gml:lowerCorner>
         <gml:upperCorner>452364.56 4368615.03</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A04000131_PI.90</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A04000131&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A04000131&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A04000131_PI.90" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 452355.95 4368611.44 452357.62 4368615.03 452364.56 4368611.81 452362.9 4368608.22 452355.95 4368611.44</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A04000144_PI.91">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451749.93 4368221.34</gml:lowerCorner>
         <gml:upperCorner>451755.16 4368228.84</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A04000144_PI.91</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A04000144&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A04000144&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A04000144_PI.91" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="22"> 451754.06 4368228.72 451754.57 4368228.42 451754.95 4368227.96 451755.15 4368227.41 451755.16 4368226.82 451754.97 4368226.26 451753.02 4368222.09 451752.62 4368221.67 451752.1 4368221.41 451751.52 4368221.34 451750.95 4368221.47 451750.77 4368221.56 451750.46 4368221.79 451750.11 4368222.25 451749.93 4368222.8 451749.95 4368223.39 451750.11 4368223.82 451751.96 4368228.05 451752.37 4368228.49 451752.89 4368228.76 451753.48 4368228.84 451754.06 4368228.72</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A04000437_PI.92">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451806.09 4368302.61</gml:lowerCorner>
         <gml:upperCorner>451815.99 4368314.57</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A04000437_PI.92</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A04000437&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A04000437&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A04000437_PI.92" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 451806.82 4368304.07 451806.09 4368305.12 451810.78 4368314.57 451815.99 4368312.25 451811.44 4368302.68 451809.72 4368302.61 451808.66 4368302.88 451807.48 4368303.41 451806.82 4368304.07</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A04000440_PI.93">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451913.87 4368524.67</gml:lowerCorner>
         <gml:upperCorner>451921.14 4368535.53</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A04000440_PI.93</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A04000440&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A04000440&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A04000440_PI.93" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 451917.31 4368535.53 451921.14 4368533.94 451917.63 4368525.46 451915.53 4368524.67 451914.06 4368526.04 451913.87 4368527.21 451917.31 4368535.53</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A04000441_PI.94">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452940.67 4368706.27</gml:lowerCorner>
         <gml:upperCorner>452951.14 4368713.86</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-05-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A04000441_PI.94</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A04000441&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A04000441&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A04000441_PI.94" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 452949.57 4368706.27 452940.67 4368709.76 452942.03 4368713.86 452951.14 4368710.29 452949.57 4368706.27</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A04100104_PI.95">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452653 4369318.38</gml:lowerCorner>
         <gml:upperCorner>452658.8 4369326.33</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A04100104_PI.95</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A04100104&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A04100104&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A04100104_PI.95" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 452653 4369319.64 452655.98 4369326.33 452658.8 4369325.08 452655.82 4369318.38 452653 4369319.64</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A04100104_PI.96">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452717.45 4369323.12</gml:lowerCorner>
         <gml:upperCorner>452724.26 4369332.4</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A04100104_PI.96</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A04100104&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A04100104&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A04100104_PI.96" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 452724.26 4369330.99 452720.18 4369323.12 452717.45 4369324.53 452721.53 4369332.4 452724.26 4369330.99</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A04100104_PI.97">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452726.32 4369358.24</gml:lowerCorner>
         <gml:upperCorner>452739.57 4369368.55</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A04100104_PI.97</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A04100104&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A04100104&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A04100104_PI.97" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17"> 452739.57 4369363.27 452736.86 4369358.24 452727.14 4369363.49 452727.65 4369364.44 452726.66 4369364.97 452726.4 4369365.51 452726.32 4369366.12 452726.44 4369366.71 452726.59 4369367.01 452726.75 4369367.24 452727.21 4369367.63 452727.78 4369367.85 452728.39 4369367.88 452728.97 4369367.71 452729.23 4369367.56 452729.81 4369368.55 452739.57 4369363.27</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A04100123_PI.98">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452933.82 4369214.83</gml:lowerCorner>
         <gml:upperCorner>452944.05 4369223.32</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A04100123_PI.98</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A04100123&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A04100123&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A04100123_PI.98" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 452936 4369223.32 452944.05 4369218.7 452941.84 4369214.83 452933.82 4369219.43 452936 4369223.32</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A04100123_PI.99">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452982.64 4369184.04</gml:lowerCorner>
         <gml:upperCorner>452992.9 4369192.55</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A04100123_PI.99</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A04100123&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A04100123&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A04100123_PI.99" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 452982.64 4369188.86 452984.86 4369192.55 452992.9 4369187.73 452990.68 4369184.04 452982.64 4369188.86</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A04100178_PI.100">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451869.88 4369034.49</gml:lowerCorner>
         <gml:upperCorner>451876.07 4369042.55</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-09-23T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A04100178_PI.100</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A04100178&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A04100178&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A04100178_PI.100" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 451872.85 4369042.55 451876.07 4369041.04 451873.18 4369034.49 451869.88 4369036.21 451872.85 4369042.55</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A04200082_PI.101">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>450833.26 4369596.05</gml:lowerCorner>
         <gml:upperCorner>450838.37 4369604.97</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A04200082_PI.101</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A04200082&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A04200082&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A04200082_PI.101" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 450833.26 4369604.28 450836.73 4369604.97 450838.37 4369596.74 450834.9 4369596.05 450833.26 4369604.28</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A05400023_PI.102">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455644.56 4380087.32</gml:lowerCorner>
         <gml:upperCorner>455666.52 4380111.36</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A05400023_PI.102</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A05400023&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A05400023&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A05400023_PI.102" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 455651.17 4380087.32 455644.56 4380093.13 455658.82 4380111.36 455666.52 4380105.33 455651.17 4380087.32</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A06000463_PI.103">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455337.33 4372325.86</gml:lowerCorner>
         <gml:upperCorner>455342.88 4372334.63</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A06000463_PI.103</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A06000463&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A06000463&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A06000463_PI.103" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 455337.33 4372333.97 455340.89 4372334.63 455342.88 4372326.71 455339.46 4372325.86 455337.33 4372333.97</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A06200045_PI.104">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455251.6 4371057.09</gml:lowerCorner>
         <gml:upperCorner>455257.14 4371065.6</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A06200045_PI.104</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A06200045&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A06200045&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A06200045_PI.104" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18"> 455252.79 4371057.16 455252.12 4371057.44 455251.6 4371057.84 455253.75 4371065.43 455254.43 4371065.6 455255.14 4371065.57 455255.8 4371065.34 455256.06 4371065.19 455256.38 4371064.93 455256.81 4371064.38 455257.08 4371063.73 455257.14 4371063.37 455255.4 4371058 455254.86 4371057.52 455254.22 4371057.21 455253.51 4371057.09 455253.26 4371057.09 455252.79 4371057.16</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A06200058_PI.105">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455767.22 4370755.72</gml:lowerCorner>
         <gml:upperCorner>455784.74 4370768.55</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A06200058_PI.105</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A06200058&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A06200058&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A06200058_PI.105" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 455769.86 4370755.72 455767.22 4370760.77 455782.1 4370768.55 455784.74 4370763.5 455769.86 4370755.72</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A06200197_PI.106">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>457086.2 4371938.51</gml:lowerCorner>
         <gml:upperCorner>457094.23 4371943.9</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A06200197_PI.106</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A06200197&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A06200197&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A06200197_PI.106" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 457086.2 4371941.15 457093.19 4371943.9 457094.23 4371941.25 457087.24 4371938.51 457086.2 4371941.15</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A06200305_PI.107">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>457002.75 4371199.89</gml:lowerCorner>
         <gml:upperCorner>457008.85 4371210.52</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A06200305_PI.107</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A06200305&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A06200305&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A06200305_PI.107" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 457003.69 4371199.89 457002.75 4371210.04 457007.91 4371210.52 457008.85 4371200.37 457003.69 4371199.89</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A06400148_PI.108">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>457633.13 4371101.46</gml:lowerCorner>
         <gml:upperCorner>457641.47 4371107.01</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A06400148_PI.108</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A06400148&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A06400148&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A06400148_PI.108" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12"> 457633.43 4371102.16 457633.18 4371102.69 457633.13 4371103.26 457633.27 4371103.82 457633.6 4371104.3 457634.03 4371104.63 457640.31 4371107.01 457641.47 4371103.93 457634.95 4371101.46 457634.37 4371101.51 457633.84 4371101.76 457633.43 4371102.16</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A06600033_PI.109">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>456133.88 4369908.31</gml:lowerCorner>
         <gml:upperCorner>456145.24 4369921.78</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A06600033_PI.109</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A06600033&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A06600033&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A06600033_PI.109" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18"> 456139.83 4369921.78 456145.24 4369912.4 456144.02 4369911.7 456144.27 4369911.07 456144.32 4369910.4 456144.17 4369909.75 456143.84 4369909.16 456143.35 4369908.7 456143.13 4369908.57 456142.74 4369908.41 456142.08 4369908.31 456141.41 4369908.4 456140.8 4369908.69 456140.31 4369909.15 456140.11 4369909.44 456138.77 4369909.1 456133.88 4369918.21 456139.83 4369921.78</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A06600081_PI.110">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455523.34 4369504.75</gml:lowerCorner>
         <gml:upperCorner>455532.09 4369513.94</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A06600081_PI.110</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A06600081&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A06600081&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A06600081_PI.110" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 455528.37 4369504.75 455523.34 4369510.85 455526.96 4369513.94 455532.09 4369507.91 455528.37 4369504.75</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A06600119_PI.111">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455448.09 4369403.54</gml:lowerCorner>
         <gml:upperCorner>455454.74 4369412.21</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A06600119_PI.111</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A06600119&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A06600119&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A06600119_PI.111" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13"> 455454.74 4369404.86 455452.1 4369403.54 455448.27 4369409.74 455448.09 4369410.29 455448.1 4369410.87 455448.31 4369411.41 455448.69 4369411.84 455449.2 4369412.12 455449.77 4369412.21 455450.33 4369412.1 455450.83 4369411.8 455451.2 4369411.34 455454.74 4369404.86</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A06700003_PI.112">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455536.39 4369312.84</gml:lowerCorner>
         <gml:upperCorner>455542.58 4369324.53</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A06700003_PI.112</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A06700003&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A06700003&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A06700003_PI.112" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15"> 455538.71 4369324.53 455539.25 4369324.43 455539.72 4369324.13 455540.05 4369323.69 455540.17 4369323.38 455541.22 4369323.52 455542.58 4369313.83 455538.37 4369312.84 455536.39 4369322.49 455537.21 4369322.65 455537.18 4369323.2 455537.35 4369323.73 455537.69 4369324.16 455538.24 4369324.47 455538.71 4369324.53</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A07000019_PI.113">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455597.65 4368510.69</gml:lowerCorner>
         <gml:upperCorner>455607.56 4368516.84</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A07000019_PI.113</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A07000019&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A07000019&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A07000019_PI.113" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 455606.67 4368510.69 455597.65 4368512.56 455598.53 4368516.84 455607.56 4368514.97 455606.67 4368510.69</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A07000178_PI.114">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455582.15 4368467.37</gml:lowerCorner>
         <gml:upperCorner>455590.54 4368472.53</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-12-23T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A07000178_PI.114</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A07000178&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A07000178&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A07000178_PI.114" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15"> 455582.15 4368470.49 455582.35 4368471.28 455582.74 4368471.99 455583.21 4368472.53 455590.19 4368471.09 455590.46 4368470.4 455590.54 4368469.67 455590.41 4368468.94 455590.29 4368468.61 455590.1 4368468.27 455589.62 4368467.71 455589.14 4368467.37 455582.35 4368468.9 455582.15 4368469.68 455582.15 4368470.49</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A07100169_PI.115">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455853.73 4368111.23</gml:lowerCorner>
         <gml:upperCorner>455860.6 4368115.85</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-12-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A07100169_PI.115</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A07100169&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A07100169&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A07100169_PI.115" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 455853.73 4368111.95 455854.17 4368115.85 455860.6 4368115.13 455860.16 4368111.23 455853.73 4368111.95</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A07100169_PI.116">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455867.44 4368101.54</gml:lowerCorner>
         <gml:upperCorner>455875.38 4368107.32</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-12-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A07100169_PI.116</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A07100169&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A07100169&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A07100169_PI.116" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 455868.32 4368107.32 455875.38 4368105.88 455874.5 4368101.54 455867.44 4368102.99 455868.32 4368107.32</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A07300144_PI.117">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454545.4 4367280.92</gml:lowerCorner>
         <gml:upperCorner>454552.96 4367291.28</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A07300144_PI.117</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A07300144&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A07300144&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A07300144_PI.117" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454545.4 4367282.55 454549.03 4367291.28 454552.96 4367289.64 454549.32 4367280.92 454545.4 4367282.55</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A07300161_PI.118">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454568.39 4367372.14</gml:lowerCorner>
         <gml:upperCorner>454578.96 4367379.5</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A07300161_PI.118</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A07300161&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A07300161&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A07300161_PI.118" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10"> 454568.39 4367375.04 454570.04 4367379.5 454572.85 4367379.5 454575.66 4367377.02 454577.64 4367377.68 454578.96 4367377.19 454577.07 4367372.14 454574.43 4367373.13 454571.03 4367372.89 454568.39 4367375.04</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A07500004_PI.119">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454195.05 4367115.72</gml:lowerCorner>
         <gml:upperCorner>454204.35 4367121.83</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-07-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A07500004_PI.119</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A07500004&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A07500004&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A07500004_PI.119" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454195.05 4367118.07 454196.13 4367121.83 454204.35 4367119.49 454203.27 4367115.72 454195.05 4367118.07</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A07500022_PI.120">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454026.62 4366678.24</gml:lowerCorner>
         <gml:upperCorner>454036.07 4366684.93</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A07500022_PI.120</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A07500022&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A07500022&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A07500022_PI.120" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454026.62 4366681.69 454028.01 4366684.93 454036.07 4366681.48 454034.68 4366678.24 454026.62 4366681.69</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A07500051_PI.121">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454382.28 4366703.61</gml:lowerCorner>
         <gml:upperCorner>454393.36 4366708.41</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-03-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A07500051_PI.121</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A07500051&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A07500051&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A07500051_PI.121" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15"> 454393.36 4366705.78 454393.22 4366705.35 454392.95 4366704.98 454392.59 4366704.72 454391.93 4366704.5 454391.93 4366703.61 454382.28 4366703.61 454382.28 4366708.41 454391.93 4366708.41 454391.93 4366707.51 454392.59 4366707.3 454392.95 4366707.03 454393.22 4366706.67 454393.36 4366706.24 454393.36 4366705.78</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A07500053_PI.122">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454422.53 4366852.31</gml:lowerCorner>
         <gml:upperCorner>454431.28 4366857.37</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2020-12-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A07500053_PI.122</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A07500053&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A07500053&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A07500053_PI.122" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19"> 454431.16 4366853.55 454430.98 4366853.31 454430.74 4366853.14 454430.46 4366853.04 454430.31 4366853.02 454430.02 4366853.06 454429.87 4366852.31 454422.53 4366853.81 454423.26 4366857.37 454430.59 4366855.87 454430.42 4366855.01 454430.7 4366854.93 454430.83 4366854.86 454430.95 4366854.77 454431.14 4366854.54 454431.25 4366854.26 454431.28 4366853.97 454431.22 4366853.68 454431.16 4366853.55</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A07500054_PI.123">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454431.1 4366746.14</gml:lowerCorner>
         <gml:upperCorner>454438.84 4366750.21</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-03-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A07500054_PI.123</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A07500054&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A07500054&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A07500054_PI.123" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454431.36 4366746.14 454431.1 4366749.63 454438.57 4366750.21 454438.84 4366746.72 454431.36 4366746.14</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A07600029_PI.124">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455100.61 4364518.54</gml:lowerCorner>
         <gml:upperCorner>455103.71 4364527.2</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A07600029_PI.124</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A07600029&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A07600029&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A07600029_PI.124" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 455100.61 4364527.2 455103.71 4364527.2 455103.71 4364518.54 455100.61 4364518.54 455100.61 4364527.2</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A07600166_PI.125">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454262.37 4364420.71</gml:lowerCorner>
         <gml:upperCorner>454271.19 4364426.29</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A07600166_PI.125</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A07600166&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A07600166&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A07600166_PI.125" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454262.37 4364423.81 454270.2 4364426.29 454271.19 4364423.19 454263.36 4364420.71 454262.37 4364423.81</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A07800040_PI.126">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452390.55 4363504.99</gml:lowerCorner>
         <gml:upperCorner>452399.87 4363513.14</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A07800040_PI.126</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A07800040&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A07800040&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A07800040_PI.126" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 452390.55 4363508.49 452397.44 4363513.14 452399.87 4363509.54 452393.14 4363504.99 452390.55 4363508.49</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A07900194_PI.127">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>451784.7 4361963.47</gml:lowerCorner>
         <gml:upperCorner>451789.47 4361973.29</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A07900194_PI.127</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A07900194&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A07900194&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A07900194_PI.127" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 451789.47 4361964.04 451786.47 4361963.47 451784.7 4361972.72 451787.7 4361973.29 451789.47 4361964.04</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08100117_PI.128">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452709.76 4364777.99</gml:lowerCorner>
         <gml:upperCorner>452721.51 4364785.64</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08100117_PI.128</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08100117&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08100117&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08100117_PI.128" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15"> 452710.04 4364779.05 452709.87 4364779.53 452709.76 4364785.64 452721.51 4364785.64 452721.51 4364780.36 452713.72 4364780.36 452713.75 4364779.73 452713.59 4364779.13 452713.24 4364778.61 452712.74 4364778.22 452712.15 4364778.01 452711.53 4364777.99 452710.93 4364778.18 452710.41 4364778.54 452710.04 4364779.05</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08200143_PI.129">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452850.06 4365823.82</gml:lowerCorner>
         <gml:upperCorner>452859.22 4365840.42</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08200143_PI.129</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08200143&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08200143&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08200143_PI.129" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 452850.06 4365839.38 452856.45 4365840.42 452859.22 4365824.97 452852.85 4365823.82 452850.06 4365839.38</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08200212_PI.130">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452387.06 4365118.59</gml:lowerCorner>
         <gml:upperCorner>452398.81 4365124</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08200212_PI.130</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08200212&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08200212&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08200212_PI.130" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14"> 452387.06 4365124 452397.1 4365123.47 452397.74 4365123.16 452398.26 4365122.68 452398.63 4365122.08 452398.81 4365121.39 452398.8 4365120.68 452398.59 4365120.01 452398.2 4365119.42 452397.66 4365118.96 452397.01 4365118.67 452396.57 4365118.59 452387.06 4365119.12 452387.06 4365124</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08200237_PI.131">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453264.25 4367166.75</gml:lowerCorner>
         <gml:upperCorner>453274.89 4367173.28</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08200237_PI.131</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08200237&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08200237&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08200237_PI.131" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453264.25 4367168.47 453265.1 4367173.28 453274.89 4367171.56 453274.04 4367166.75 453264.25 4367168.47</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08300086_PI.132">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453044.9 4366898.73</gml:lowerCorner>
         <gml:upperCorner>453049.28 4366905.21</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2026-06-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08300086_PI.132</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08300086&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08300086&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08300086_PI.132" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18"> 453046.55 4366898.74 453046.33 4366898.79 453045.95 4366898.94 453045.44 4366899.32 453045.07 4366899.85 453044.9 4366900.38 453045.91 4366904.96 453046.62 4366905.18 453047.36 4366905.21 453047.59 4366905.18 453048.09 4366905.04 453048.74 4366904.69 453049.28 4366904.17 453048.69 4366899.8 453048.31 4366899.28 453047.79 4366898.92 453047.18 4366898.73 453046.55 4366898.74</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08300086_PI.133">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453066.95 4367118.99</gml:lowerCorner>
         <gml:upperCorner>453076.1 4367124.48</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2026-06-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08300086_PI.133</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08300086&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08300086&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08300086_PI.133" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14"> 453066.95 4367121.05 453067.86 4367124.48 453073.24 4367123.05 453073.34 4367123.57 453073.62 4367124.03 453074.06 4367124.34 453074.57 4367124.48 453075.1 4367124.42 453075.58 4367124.16 453075.92 4367123.75 453076.09 4367123.24 453076.1 4367123.05 453074.69 4367118.99 453066.95 4367121.05</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08300090_PI.134">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452953.52 4366846.14</gml:lowerCorner>
         <gml:upperCorner>452957.35 4366852.57</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08300090_PI.134</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08300090&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08300090&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08300090_PI.134" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18"> 452954.6 4366846.16 452954.11 4366846.38 452953.74 4366846.76 452953.53 4366847.25 452953.52 4366847.79 452954.58 4366851.62 452954.86 4366852.09 452955.29 4366852.42 452955.81 4366852.57 452956.35 4366852.53 452956.84 4366852.29 452957.21 4366851.89 452957.35 4366851.62 452956.29 4366847.13 452956.04 4366846.66 452955.64 4366846.31 452955.13 4366846.14 452954.6 4366846.16</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400009_PI.135">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453883.29 4368242.82</gml:lowerCorner>
         <gml:upperCorner>453893.62 4368256.28</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400009_PI.135</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400009&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400009&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400009_PI.135" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17"> 453891.59 4368242.9 453890.99 4368242.89 453890.41 4368243.07 453889.93 4368243.43 453889.77 4368243.63 453888.78 4368242.82 453883.29 4368253.64 453888.05 4368256.28 453893.62 4368246.24 453892.72 4368245.74 453892.99 4368245.2 453893.06 4368244.6 453892.93 4368244.01 453892.62 4368243.5 453892.36 4368243.25 453892.16 4368243.12 453891.59 4368242.9</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400023_PI.136">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454141.23 4367834.23</gml:lowerCorner>
         <gml:upperCorner>454149.61 4367844.47</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-15T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400023_PI.136</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400023&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400023&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400023_PI.136" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454141.23 4367836.25 454144.45 4367844.47 454149.61 4367842.45 454146.39 4367834.23 454141.23 4367836.25</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400039_PI.137">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454068.39 4367450.71</gml:lowerCorner>
         <gml:upperCorner>454081.13 4367457.76</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400039_PI.137</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400039&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400039&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400039_PI.137" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454069.22 4367457.76 454081.13 4367455.81 454080.3 4367450.71 454068.39 4367452.65 454069.22 4367457.76</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400045_PI.138">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453788.32 4367282.55</gml:lowerCorner>
         <gml:upperCorner>453796.15 4367294.96</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-07-03T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400045_PI.138</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400045&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400045&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400045_PI.138" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14"> 453793.34 4367282.55 453788.32 4367284.53 453791.86 4367293.49 453792.17 4367294.08 453792.65 4367294.54 453793.24 4367294.85 453793.86 4367294.96 453794.56 4367294.87 453795.16 4367294.59 453795.66 4367294.15 453796 4367293.58 453796.15 4367292.93 453796.11 4367292.26 453793.34 4367282.55</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400045_PI.139">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453826.17 4367256.85</gml:lowerCorner>
         <gml:upperCorner>453835.73 4367263.4</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-07-03T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400045_PI.139</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400045&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400045&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400045_PI.139" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453826.17 4367258.7 453827.2 4367263.4 453835.73 4367261.55 453834.7 4367256.85 453826.17 4367258.7</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400045_PI.140">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453839.4 4367229.14</gml:lowerCorner>
         <gml:upperCorner>453848.4 4367242.8</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-07-03T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400045_PI.140</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400045&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400045&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400045_PI.140" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18"> 453842.26 4367229.14 453841.64 4367229.24 453841.08 4367229.54 453840.64 4367229.99 453840.37 4367230.56 453840.28 4367231.19 453840.4 4367231.81 453840.61 4367232.23 453839.4 4367232.84 453842.72 4367242.8 453848.4 4367240.82 453845.63 4367230.78 453844.28 4367231.15 453844.19 4367230.53 453843.9 4367229.96 453843.45 4367229.52 453842.89 4367229.23 453842.26 4367229.14</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400045_PI.141">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453853.45 4367326.63</gml:lowerCorner>
         <gml:upperCorner>453862.2 4367332.38</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400045_PI.141</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400045&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400045&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400045_PI.141" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16"> 453854.54 4367332.38 453861.82 4367330.05 453861.67 4367329.6 453861.87 4367329.44 453862 4367329.26 453862.13 4367328.99 453862.2 4367328.48 453862.12 4367328.01 453861.87 4367327.53 453861.53 4367327.2 453861.32 4367327.08 453861.1 4367327.01 453860.84 4367326.99 453860.72 4367326.63 453853.45 4367328.96 453854.54 4367332.38</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400047_PI.142">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453786.22 4367414.26</gml:lowerCorner>
         <gml:upperCorner>453794.19 4367419.15</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400047_PI.142</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400047&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400047&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400047_PI.142" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14"> 453787.05 4367419.15 453793.35 4367417.18 453793.79 4367416.84 453794.08 4367416.36 453794.19 4367415.82 453794.1 4367415.27 453794.01 4367415.07 453793.81 4367414.78 453793.38 4367414.43 453792.85 4367414.26 453792.3 4367414.28 453791.92 4367414.41 453786.22 4367415.86 453787.05 4367419.15</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400050_PI.143">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453784.11 4367485.27</gml:lowerCorner>
         <gml:upperCorner>453794.86 4367492.87</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400050_PI.143</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400050&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400050&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400050_PI.143" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14"> 453784.11 4367488.13 453785.61 4367492.87 453791.03 4367490.94 453791.38 4367491.48 453791.88 4367491.88 453792.48 4367492.11 453793.12 4367492.14 453793.73 4367491.97 453793.94 4367491.87 453794.27 4367491.62 453794.67 4367491.13 453794.86 4367490.68 453793.14 4367485.27 453784.11 4367488.13</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400093_PI.144">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453767.15 4367739.12</gml:lowerCorner>
         <gml:upperCorner>453776.27 4367744.98</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2017-11-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400093_PI.144</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400093&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400093&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400093_PI.144" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453776.27 4367743.76 453775.51 4367739.12 453767.15 4367740.33 453767.82 4367744.98 453776.27 4367743.76</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400100_PI.145">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453972.35 4367714.49</gml:lowerCorner>
         <gml:upperCorner>453982.6 4367721.74</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400100_PI.145</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400100&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400100&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400100_PI.145" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453981.16 4367714.49 453972.35 4367717.65 453973.74 4367721.74 453982.6 4367718.74 453981.16 4367714.49</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400107_PI.146">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453279.32 4368166.05</gml:lowerCorner>
         <gml:upperCorner>453290 4368173.54</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400107_PI.146</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400107&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400107&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400107_PI.146" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453279.32 4368169.36 453281.2 4368173.54 453290 4368170.35 453288.44 4368166.05 453279.32 4368169.36</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400107_PI.147">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453337.87 4368221.91</gml:lowerCorner>
         <gml:upperCorner>453345.42 4368232.41</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400107_PI.147</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400107&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400107&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400107_PI.147" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453345.42 4368230.86 453342.07 4368221.91 453337.87 4368223.28 453341.28 4368232.41 453345.42 4368230.86</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400117_PI.148">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453324.91 4367733.36</gml:lowerCorner>
         <gml:upperCorner>453334.02 4367740.76</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400117_PI.148</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400117&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400117&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400117_PI.148" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14"> 453333.1 4367733.36 453324.91 4367734.42 453325.61 4367739.83 453325.92 4367740.29 453326.38 4367740.61 453326.92 4367740.75 453327.02 4367740.76 453327.48 4367740.69 453327.98 4367740.44 453328.36 4367740.03 453328.57 4367739.51 453328.6 4367739.17 453334.02 4367738.38 453333.1 4367733.36</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400130_PI.149">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452904.93 4367268.11</gml:lowerCorner>
         <gml:upperCorner>452917.32 4367274.46</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400130_PI.149</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400130&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400130&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400130_PI.149" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15"> 452917.23 4367269.97 452916.94 4367269.31 452916.49 4367268.76 452915.9 4367268.36 452915.22 4367268.14 452914.5 4367268.11 452904.93 4367269.93 452905.54 4367274.46 452915.17 4367273.17 452915.86 4367272.96 452916.45 4367272.57 452916.92 4367272.03 452917.22 4367271.38 452917.32 4367270.68 452917.23 4367269.97</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400134_PI.150">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452813.86 4367520.75</gml:lowerCorner>
         <gml:upperCorner>452824.99 4367528.69</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400134_PI.150</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400134&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400134&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400134_PI.150" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15"> 452824.85 4367527.05 452824.99 4367526.5 452824.94 4367525.99 452823.05 4367520.75 452813.86 4367523.49 452815.42 4367528.69 452821.8 4367526.79 452822.03 4367527.31 452822.43 4367527.71 452822.95 4367527.95 452823.51 4367528 452824.06 4367527.85 452824.36 4367527.67 452824.53 4367527.52 452824.85 4367527.05</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400157_PI.151">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453200.45 4368379.33</gml:lowerCorner>
         <gml:upperCorner>453208.78 4368385.45</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-15T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400157_PI.151</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400157&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400157&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400157_PI.151" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453200.45 4368382.37 453201.79 4368385.45 453208.78 4368382.41 453207.44 4368379.33 453200.45 4368382.37</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400157_PI.152">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453237.98 4368429.34</gml:lowerCorner>
         <gml:upperCorner>453244.89 4368438.55</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-15T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400157_PI.152</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400157&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400157&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400157_PI.152" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453241.58 4368438.55 453244.89 4368436.99 453241.29 4368429.34 453237.98 4368430.9 453241.58 4368438.55</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400157_PI.153">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453247.06 4368414.73</gml:lowerCorner>
         <gml:upperCorner>453255.41 4368421.24</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-15T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400157_PI.153</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400157&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400157&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400157_PI.153" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453253.86 4368414.73 453247.06 4368417.93 453248.62 4368421.24 453255.41 4368418.04 453253.86 4368414.73</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400168_PI.154">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453169.07 4368191.58</gml:lowerCorner>
         <gml:upperCorner>453175.16 4368201.43</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400168_PI.154</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400168&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400168&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400168_PI.154" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11"> 453173.79 4368201.31 453174.7 4368200.59 453175.16 4368199.14 453174.7 4368196.59 453172.45 4368191.58 453170.19 4368192.08 453169.27 4368192.66 453169.07 4368194.65 453171.44 4368197.17 453171.69 4368201.43 453173.79 4368201.31</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400208_PI.155">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453122.67 4367937.54</gml:lowerCorner>
         <gml:upperCorner>453127.95 4367943.61</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-06-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400208_PI.155</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400208&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400208&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400208_PI.155" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453122.67 4367938.79 453125.18 4367943.61 453127.95 4367942.42 453125.38 4367937.54 453122.67 4367938.79</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400223_PI.156">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453317.29 4368100.47</gml:lowerCorner>
         <gml:upperCorner>453324.7 4368105.8</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400223_PI.156</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400223&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400223&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400223_PI.156" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453317.29 4368102.4 453318.32 4368105.8 453324.7 4368103.87 453323.67 4368100.47 453317.29 4368102.4</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400226_PI.157">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454290.97 4367837.37</gml:lowerCorner>
         <gml:upperCorner>454298.08 4367846.28</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400226_PI.157</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400226&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400226&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400226_PI.157" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454298.08 4367844.6 454295.22 4367837.37 454290.97 4367839.05 454293.84 4367846.28 454298.08 4367844.6</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400241_PI.158">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453364.58 4368203.67</gml:lowerCorner>
         <gml:upperCorner>453372.63 4368214.59</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400241_PI.158</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400241&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400241&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400241_PI.158" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16"> 453364.58 4368205.39 453367.09 4368211.06 453366.52 4368211.26 453366.06 4368211.63 453365.74 4368212.14 453365.61 4368212.72 453365.68 4368213.31 453365.94 4368213.85 453366.03 4368213.97 453366.36 4368214.27 453366.9 4368214.53 453367.49 4368214.59 453367.68 4368214.57 453372.63 4368213.04 453368.94 4368203.67 453364.58 4368205.39</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400241_PI.159">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453379.88 4368195.28</gml:lowerCorner>
         <gml:upperCorner>453385.9 4368203.14</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400241_PI.159</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400241&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400241&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400241_PI.159" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453383.05 4368195.28 453379.88 4368196.68 453382.74 4368203.14 453385.9 4368201.74 453383.05 4368195.28</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400241_PI.160">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453399.18 4368179.7</gml:lowerCorner>
         <gml:upperCorner>453406.24 4368190.58</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400241_PI.160</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400241&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400241&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400241_PI.160" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12"> 453405.32 4368190.15 453405.8 4368189.67 453406.12 4368189.08 453406.24 4368188.42 453403.07 4368179.7 453399.18 4368181.09 453402.28 4368189.8 453402.79 4368190.24 453403.4 4368190.51 453404.07 4368190.58 453404.72 4368190.46 453405.32 4368190.15</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400273_PI.161">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453048.81 4367759.69</gml:lowerCorner>
         <gml:upperCorner>453054.33 4367764.6</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-02-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400273_PI.161</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400273&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400273&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400273_PI.161" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="22"> 453049.21 4367764 453049.78 4367764.44 453050.35 4367764.6 453050.93 4367764.55 453051.3 4367764.41 453052.07 4367764.33 453052.79 4367764.05 453053.41 4367763.59 453053.89 4367762.99 453054.23 4367762.22 453054.33 4367761.52 453054.23 4367760.65 453054.05 4367760.27 453053.68 4367759.9 453053.2 4367759.7 453052.68 4367759.69 453052.19 4367759.88 453049.1 4367761.94 453048.86 4367762.48 453048.81 4367763.06 453048.97 4367763.62 453049.21 4367764</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08400274_PI.162">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453193.93 4367950.82</gml:lowerCorner>
         <gml:upperCorner>453199.48 4367957.46</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-06-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08400274_PI.162</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08400274&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08400274&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08400274_PI.162" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="20"> 453194.74 4367951.22 453194.5 4367951.43 453194.13 4367951.96 453193.93 4367952.58 453193.94 4367953.22 453194.13 4367953.82 453196.27 4367957.03 453196.82 4367957.34 453197.44 4367957.46 453198.06 4367957.38 453198.63 4367957.11 453199.08 4367956.68 453199.38 4367956.12 453199.48 4367955.42 453197.42 4367951.37 453196.89 4367951.01 453196.27 4367950.82 453195.62 4367950.84 453195.02 4367951.05 453194.74 4367951.22</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08401072_PI.163">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453375.07 4367833.01</gml:lowerCorner>
         <gml:upperCorner>453378.68 4367841.5</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-15T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08401072_PI.163</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08401072&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08401072&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08401072_PI.163" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453375.34 4367841.5 453378.68 4367841.39 453378.41 4367833.01 453375.07 4367833.12 453375.34 4367841.5</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08500053_PI.164">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454300.87 4368214.49</gml:lowerCorner>
         <gml:upperCorner>454312.2 4368222.12</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08500053_PI.164</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08500053&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08500053&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08500053_PI.164" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454300.87 4368218.11 454302.41 4368222.12 454312.2 4368218.52 454310.72 4368214.49 454300.87 4368218.11</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08600043_PI.165">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453405.26 4370436.99</gml:lowerCorner>
         <gml:upperCorner>453416.88 4370444.34</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-07-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08600043_PI.165</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08600043&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08600043&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08600043_PI.165" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16"> 453415.48 4370444.34 453416.88 4370439.6 453408.41 4370437.11 453407.72 4370436.99 453407.03 4370437.08 453406.39 4370437.36 453405.86 4370437.8 453405.57 4370438.2 453405.47 4370438.38 453405.27 4370439.05 453405.26 4370439.75 453405.45 4370440.42 453405.83 4370441.01 453406.35 4370441.46 453406.93 4370441.74 453415.48 4370444.34</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08700015_PI.166">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453201.47 4370221.63</gml:lowerCorner>
         <gml:upperCorner>453206.32 4370228.08</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08700015_PI.166</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08700015&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08700015&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08700015_PI.166" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453201.47 4370226.99 453204.13 4370228.08 453206.32 4370222.71 453203.66 4370221.63 453201.47 4370226.99</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08700015_PI.167">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453249.58 4370234.67</gml:lowerCorner>
         <gml:upperCorner>453259.96 4370242.09</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08700015_PI.167</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08700015&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08700015&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08700015_PI.167" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453259.96 4370237.98 453251.12 4370234.67 453249.58 4370238.78 453258.42 4370242.09 453259.96 4370237.98</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08700126_PI.168">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>452168.79 4369771.19</gml:lowerCorner>
         <gml:upperCorner>452191.56 4369783.33</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08700126_PI.168</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08700126&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08700126&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08700126_PI.168" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="57"> 452190.71 4369771.28 452185.23 4369773.23 452184.66 4369772.5 452183.95 4369771.9 452183.13 4369771.48 452182.24 4369771.23 452181.31 4369771.19 452180.4 4369771.34 452179.49 4369771.72 452178.73 4369772.25 452178.1 4369772.93 452177.64 4369773.73 452177.36 4369774.62 452177.3 4369775.21 452176.91 4369774.78 452176.11 4369774.2 452175.2 4369773.8 452174.24 4369773.59 452173.25 4369773.57 452172.28 4369773.75 452171.35 4369774.13 452170.53 4369774.69 452169.84 4369775.39 452169.31 4369776.22 452168.95 4369777.15 452168.79 4369778.12 452168.82 4369779.11 452169.06 4369780.07 452169.48 4369780.96 452170.07 4369781.76 452170.81 4369782.41 452171.67 4369782.9 452172.61 4369783.21 452173.59 4369783.33 452174.58 4369783.24 452175.05 4369783.13 452175.52 4369782.96 452176.4 4369782.5 452177.16 4369781.86 452177.77 4369781.09 452178.22 4369780.21 452178.49 4369779.26 452178.54 4369778.49 452178.83 4369778.79 452179.6 4369779.3 452180.47 4369779.63 452181.38 4369779.77 452182.31 4369779.71 452182.79 4369779.59 452183.2 4369779.45 452184.01 4369779.01 452184.71 4369778.4 452185.27 4369777.66 452185.65 4369776.81 452185.84 4369775.9 452191.56 4369774.28 452190.71 4369771.28</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08700171_PI.169">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453068.75 4369705.94</gml:lowerCorner>
         <gml:upperCorner>453076.19 4369711.86</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-15T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08700171_PI.169</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08700171&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08700171&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08700171_PI.169" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453068.75 4369708.85 453070.22 4369711.86 453076.19 4369708.95 453074.72 4369705.94 453068.75 4369708.85</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08700172_PI.170">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453102.64 4369674.71</gml:lowerCorner>
         <gml:upperCorner>453109.01 4369683.29</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-15T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08700172_PI.170</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08700172&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08700172&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08700172_PI.170" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17"> 453103.46 4369674.95 453103.29 4369675.15 453103.15 4369675.44 453103.11 4369675.68 453103.13 4369675.94 453103.22 4369676.18 453102.64 4369676.46 453106.02 4369683.29 453109.01 4369681.81 453105.63 4369674.98 453105.05 4369675.27 453104.86 4369674.99 453104.6 4369674.81 453104.26 4369674.71 453103.94 4369674.72 453103.64 4369674.83 453103.46 4369674.95</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08700173_PI.171">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453092.83 4369654.54</gml:lowerCorner>
         <gml:upperCorner>453104.71 4369663.68</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-15T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08700173_PI.171</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08700173&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08700173&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08700173_PI.171" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="21"> 453095.08 4369663.68 453104.35 4369659.26 453103.87 4369658.24 453104.11 4369658.1 453104.32 4369657.91 453104.54 4369657.6 453104.7 4369657.15 453104.71 4369656.72 453104.65 4369656.45 453104.54 4369656.2 453104.38 4369655.95 453104.18 4369655.75 453103.97 4369655.61 453103.72 4369655.49 453103.43 4369655.42 453103.11 4369655.41 453102.79 4369655.47 453102.59 4369655.55 453102.1 4369654.54 453092.83 4369658.95 453095.08 4369663.68</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A08700232_PI.172">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>453110.01 4369424.22</gml:lowerCorner>
         <gml:upperCorner>453116.26 4369429.48</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-05-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A08700232_PI.172</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A08700232&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A08700232&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A08700232_PI.172" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 453114.84 4369424.22 453110.01 4369427 453111.39 4369429.48 453116.26 4369426.77 453114.84 4369424.22</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A09800054_PI.173">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454729.74 4376546.19</gml:lowerCorner>
         <gml:upperCorner>454737.76 4376553.11</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A09800054_PI.173</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A09800054&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A09800054&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A09800054_PI.173" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="21"> 454730.22 4376552.14 454730.48 4376552.43 454731.04 4376552.84 454731.7 4376553.08 454732.4 4376553.11 454732.73 4376553.06 454737.48 4376550.15 454737.72 4376549.45 454737.76 4376548.71 454737.6 4376547.98 454737.25 4376547.33 454736.82 4376546.85 454736.11 4376546.4 454735.39 4376546.2 454734.71 4376546.19 454730.22 4376549.23 454729.89 4376549.84 454729.74 4376550.53 454729.8 4376551.22 454730.05 4376551.88 454730.22 4376552.14</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A10000036_PI.174">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455075.22 4375796.06</gml:lowerCorner>
         <gml:upperCorner>455081.83 4375806.85</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A10000036_PI.174</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A10000036&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A10000036&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A10000036_PI.174" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13"> 455080.4 4375796.06 455075.22 4375796.92 455076.97 4375805.87 455077.62 4375806.36 455078.27 4375806.7 455078.99 4375806.85 455079.85 4375806.78 455080.42 4375806.56 455081.03 4375806.14 455081.5 4375805.57 455081.8 4375804.9 455081.83 4375804.8 455080.4 4375796.06</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A10000038_PI.175">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455022.77 4375719.2</gml:lowerCorner>
         <gml:upperCorner>455025.35 4375723.82</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A10000038_PI.175</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A10000038&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A10000038&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A10000038_PI.175" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 455025.35 4375719.2 455022.77 4375719.2 455022.77 4375723.82 455025.35 4375723.82 455025.35 4375719.2</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A10000069_PI.176">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454908.89 4374627.46</gml:lowerCorner>
         <gml:upperCorner>454918.57 4374632.81</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-11T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A10000069_PI.176</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A10000069&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A10000069&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A10000069_PI.176" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454908.89 4374632.81 454918.57 4374632.81 454918.57 4374627.46 454908.89 4374627.46 454908.89 4374632.81</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.45088A10000280_PI.177">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455055.16 4375639.68</gml:lowerCorner>
         <gml:upperCorner>455064.6 4375653.54</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2026-02-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>45088A10000280_PI.177</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=45088A10000280&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=45088A10000280&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.45088A10000280_PI.177" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18"> 455058.64 4375653.54 455064.6 4375652.07 455062.13 4375643.45 455062.71 4375643.26 455063.2 4375642.89 455063.55 4375642.38 455063.72 4375641.78 455063.68 4375641.17 455063.6 4375640.89 455063.45 4375640.59 455063.05 4375640.12 455062.52 4375639.81 455061.92 4375639.68 455061.31 4375639.75 455060.75 4375640.01 455060.57 4375640.15 455055.16 4375641.62 455058.64 4375653.54</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4594007VJ5649S_PI.178">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454466.376998757 4369154.44877055</gml:lowerCorner>
         <gml:upperCorner>454476.955742511 4369160.89174301</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4594007VJ5649S_PI.178</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4594007VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4594007VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4594007VJ5649S_PI.178" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14"> 454467.434959609 4369160.89174301 454476.395855483 4369158.68444938 454476.161988963 4369157.75541416 454476.720153856 4369157.31308854 454476.938030512 4369156.80217782 454476.955742511 4369156.25209939 454476.925077221 4369156.09222556 454476.69295777 4369155.5831867 454476.301380463 4369155.20481227 454475.790428147 4369154.9769357 454475.480347635 4369154.95822537 454475.348227319 4369154.44877055 454466.376998757 4369156.57610646 454467.434959609 4369160.89174301</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4594015VJ5649S_PI.179">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454546.790878991 4369132.21852271</gml:lowerCorner>
         <gml:upperCorner>454552.0161665 4369140.30277888</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4594015VJ5649S_PI.179</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4594015VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4594015VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4594015VJ5649S_PI.179" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454549.886401306 4369132.21852271 454546.790878991 4369133.30140849 454548.880020578 4369140.30277888 454552.0161665 4369139.36972542 454549.886401306 4369132.21852271</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4594041VJ5649S_PI.180">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454425.467298867 4369171.99172726</gml:lowerCorner>
         <gml:upperCorner>454428.560000864 4369176.25526773</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4594041VJ5649S_PI.180</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4594041VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4594041VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4594041VJ5649S_PI.180" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454427.434786011 4369171.99172726 454425.467298867 4369172.59991665 454426.59251372 4369176.25526773 454428.560000864 4369175.64707834 454427.434786011 4369171.99172726</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4602001VJ5740S_PI.181">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454467.89 4370006.21</gml:lowerCorner>
         <gml:upperCorner>454479.34 4370020.63</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-12-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4602001VJ5740S_PI.181</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4602001VJ5740S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4602001VJ5740S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4602001VJ5740S_PI.181" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454473.4 4370006.21 454467.89 4370017.22 454473.62 4370020.63 454479.34 4370009.18 454473.4 4370006.21</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4685006VJ5648N_PI.182">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454454.38260168 4368138.91371292</gml:lowerCorner>
         <gml:upperCorner>454460.65260168 4368147.92371292</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-10-23T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4685006VJ5648N_PI.182</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4685006VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4685006VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4685006VJ5648N_PI.182" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454460.65260168 4368146.60371292 454457.92260168 4368138.91371292 454454.38260168 4368139.87371292 454456.56260168 4368147.92371292 454460.65260168 4368146.60371292</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4685032VJ5648N_PI.183">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454490.446172954 4368235.0058438</gml:lowerCorner>
         <gml:upperCorner>454495.087034537 4368238.7921967</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4685032VJ5648N_PI.183</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4685032VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4685032VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4685032VJ5648N_PI.183" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454495.087034537 4368237.47294844 454494.22715392 4368235.0058438 454490.446172954 4368236.33501005 454491.316134905 4368238.7921967 454495.087034537 4368237.47294844</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4685037VJ5648N_PI.184">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454469.261480216 4368238.06941709</gml:lowerCorner>
         <gml:upperCorner>454475.320071366 4368246.79447096</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4685037VJ5648N_PI.184</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4685037VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4685037VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4685037VJ5648N_PI.184" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17"> 454469.261480216 4368239.27209936 454470.738191466 4368243.35429532 454470.396569468 4368243.55151198 454470.255430802 4368243.69036398 454470.062660466 4368244.02880097 454469.989559461 4368244.40821663 454470.007925458 4368244.60837329 454470.134981117 4368244.96942296 454470.253670446 4368245.13039762 454470.392522442 4368245.27153629 454470.730877768 4368245.47430629 454471.110375095 4368245.53740763 454471.500933757 4368245.47059497 454471.97013773 4368246.79447096 454475.320071366 4368245.59178869 454472.611413852 4368238.06941709 454469.261480216 4368239.27209936</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4685074VJ5648N_PI.185">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454398.82 4368198.39</gml:lowerCorner>
         <gml:upperCorner>454404.06 4368205.45</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-06-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4685074VJ5648N_PI.185</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4685074VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4685074VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4685074VJ5648N_PI.185" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454402 4368198.39 454398.82 4368199.54 454400.87 4368205.45 454404.06 4368204.33 454402 4368198.39</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4685076VJ5648N_PI.186">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454410.15 4368193.19</gml:lowerCorner>
         <gml:upperCorner>454417.46 4368198.29</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-06-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4685076VJ5648N_PI.186</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4685076VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4685076VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4685076VJ5648N_PI.186" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454411.14 4368198.29 454417.46 4368196.02 454416.46 4368193.19 454410.15 4368195.46 454411.14 4368198.29</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4685090VJ5648N_PI.187">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454432.784175954 4368244.84637851</gml:lowerCorner>
         <gml:upperCorner>454441.633998807 4368251.16479765</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4685090VJ5648N_PI.187</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4685090VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4685090VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4685090VJ5648N_PI.187" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454440.374993549 4368244.84637851 454432.784175954 4368247.36447069 454434.033181545 4368251.16479765 454441.633998807 4368248.64678714 454440.374993549 4368244.84637851</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4685091VJ5648N_PI.188">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454406.705689017 4368274.78149848</gml:lowerCorner>
         <gml:upperCorner>454414.007651602 4368279.89039436</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-10-23T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4685091VJ5648N_PI.188</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4685091VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4685091VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4685091VJ5648N_PI.188" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454407.691816524 4368279.89039436 454414.007651602 4368277.86922459 454413.021524095 4368274.78149848 454406.705689017 4368276.80266825 454407.691816524 4368279.89039436</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4692101VJ5649S_PI.189">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454317.56759862 4369067.49890447</gml:lowerCorner>
         <gml:upperCorner>454325.80759862 4369080.00890447</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4692101VJ5649S_PI.189</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4692101VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4692101VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4692101VJ5649S_PI.189" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454325.80759862 4369078.67890447 454323.10759862 4369067.49890447 454317.56759862 4369068.83890447 454320.28759862 4369080.00890447 454325.80759862 4369078.67890447</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4693034VJ5649S_PI.190">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454527.8275 4369070.054</gml:lowerCorner>
         <gml:upperCorner>454536.223 4369074.1</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2025-08-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4693034VJ5649S_PI.190</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4693034VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4693034VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4693034VJ5649S_PI.190" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454528.325 4369074.1 454536.223 4369071.9195 454535.7665 4369070.054 454527.8275 4369071.997 454528.325 4369074.1</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4693050VJ5649S_PI.191">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454403.407523365 4369101.85218031</gml:lowerCorner>
         <gml:upperCorner>454413.697523365 4369108.99218031</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4693050VJ5649S_PI.191</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4693050VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4693050VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4693050VJ5649S_PI.191" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18"> 454403.697523365 4369107.61218031 454404.017523365 4369107.99218031 454404.427523365 4369108.28218031 454404.887523365 4369108.45218031 454405.387523365 4369108.50218031 454405.877523365 4369108.42218031 454406.047523365 4369108.99218031 454413.697523365 4369106.63218031 454412.227523365 4369101.85218031 454404.577523365 4369104.21218031 454404.757523365 4369104.77218031 454404.297523365 4369104.98218031 454403.917523365 4369105.30218031 454403.627523365 4369105.70218031 454403.457523365 4369106.17218031 454403.407523365 4369106.67218031 454403.497523365 4369107.16218031 454403.697523365 4369107.61218031</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4694107VJ5649S_PI.192">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454513.367488478 4369210.6737087</gml:lowerCorner>
         <gml:upperCorner>454519.541826677 4369215.42328306</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4694107VJ5649S_PI.192</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4694107VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4694107VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4694107VJ5649S_PI.192" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454513.367488478 4369212.60845389 454514.441144268 4369215.42328306 454519.541826677 4369213.48853787 454518.468170887 4369210.6737087 454513.367488478 4369212.60845389</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4699022VJ5649N_PI.193">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454467.864 4369671.7567</gml:lowerCorner>
         <gml:upperCorner>454479.7938 4369685.45425</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4699022VJ5649N_PI.193</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4699022VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4699022VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4699022VJ5649N_PI.193" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454473.64745 4369671.7567 454467.864 4369675.0914 454473.25845 4369685.45425 454479.7938 4369682.7807 454473.64745 4369671.7567</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4699026VJ5649N_PI.194">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454552.718070967 4369707.24470346</gml:lowerCorner>
         <gml:upperCorner>454562.988070967 4369715.75470346</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4699026VJ5649N_PI.194</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4699026VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4699026VJ5649N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4699026VJ5649N_PI.194" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 454561.038070967 4369707.24470346 454558.708070967 4369708.04470346 454559.198070967 4369709.48470346 454552.718070967 4369711.64470346 454554.768070967 4369715.75470346 454562.988070967 4369712.93470346 454561.038070967 4369707.24470346</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4784913VJ5648S_PI.195">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454610.429406716 4368183.27665182</gml:lowerCorner>
         <gml:upperCorner>454616.701899721 4368191.29726436</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4784913VJ5648S_PI.195</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4784913VJ5648S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4784913VJ5648S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4784913VJ5648S_PI.195" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 454612.944136841 4368191.29726436 454616.701899721 4368189.85185157 454614.20741614 4368183.27665182 454610.429406716 4368184.73155554 454611.433299406 4368187.35778848 454611.180091145 4368187.48142333 454611.499494047 4368188.2997642 454611.781427999 4368188.22687218 454612.944136841 4368191.29726436</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4788016VJ5648N_PI.196">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454574.288446938 4368517.15921093</gml:lowerCorner>
         <gml:upperCorner>454583.221630568 4368521.94627849</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-10-23T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4788016VJ5648N_PI.196</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4788016VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4788016VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4788016VJ5648N_PI.196" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 454574.288446938 4368517.84345825 454575.185645922 4368521.94627849 454583.221630568 4368520.04135047 454582.540622748 4368517.15921093 454576.976467531 4368518.48185098 454576.680245545 4368517.27092054 454574.288446938 4368517.84345825</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4788019VJ5648N_PI.197">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454504.251570206 4368397.69409517</gml:lowerCorner>
         <gml:upperCorner>454510.269842646 4368403.90940407</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-10-23T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4788019VJ5648N_PI.197</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4788019VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4788019VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4788019VJ5648N_PI.197" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454508.357626139 4368397.69409517 454504.251570206 4368400.26879222 454505.883715377 4368403.90940407 454510.269842646 4368401.95308417 454508.357626139 4368397.69409517</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4794006VJ5649S_PI.198">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454579.098260574 4369237.74846013</gml:lowerCorner>
         <gml:upperCorner>454588.023817802 4369241.96646899</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4794006VJ5649S_PI.198</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4794006VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4794006VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4794006VJ5649S_PI.198" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18"> 454579.362432752 4369237.74846013 454579.098260574 4369241.42746993 454586.626240383 4369241.96646899 454586.668435521 4369241.39662728 454587.108624839 4369241.34832237 454587.509353683 4369241.15986444 454587.810583983 4369240.84102231 454587.921314978 4369240.65144739 454587.992123303 4369240.44171857 454588.023817802 4369240.00183738 454587.984665459 4369239.78168495 454587.905436381 4369239.5813783 454587.646824899 4369239.22037954 454587.47736539 4369239.0797258 454587.078061652 4369238.89818648 454586.858178833 4369238.86733934 454586.900412487 4369238.28749771 454579.362432752 4369237.74846013</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4800004VJ5740S_PI.199">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454650.406 4369877.029</gml:lowerCorner>
         <gml:upperCorner>454675.686 4369909.379</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2001-09-19T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4800004VJ5740S_PI.199</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4800004VJ5740S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4800004VJ5740S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4800004VJ5740S_PI.199" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 454662.206 4369877.029 454650.406 4369905.609 454659.546 4369909.379 454667.096 4369891.099 454671.436 4369892.889 454675.686 4369882.599 454662.206 4369877.029</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4885701VJ5648N_PI.200">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454772.081 4368335.9695</gml:lowerCorner>
         <gml:upperCorner>454781.541 4368344.34</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4885701VJ5648N_PI.200</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4885701VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4885701VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4885701VJ5648N_PI.200" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 454781.541 4368343.11 454780.29 4368336.4225 454780.214 4368335.9695 454772.081 4368337.425 454773.25 4368342.44 454775.96 4368344.34 454781.541 4368343.11</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                  <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16"> 454774.32 4368338.04 454779.41 4368337.13 454780.38 4368342.34 454777.84 4368342.9 454777.16 4368342.78 454776.53 4368342.5 454775.98 4368342.08 454775.54 4368341.54 454775.25 4368340.91 454775.12 4368340.24 454774.74 4368340.02 454774.43 4368339.72 454774.2 4368339.35 454774.07 4368338.94 454774.04 4368338.5 454774.32 4368338.04</gml:posList>
                    </gml:LinearRing>
                  </gml:interior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4888039VJ5648N_PI.201">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454686.644450855 4368580.6787384</gml:lowerCorner>
         <gml:upperCorner>454694.3060489 4368585.93904964</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-10-23T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4888039VJ5648N_PI.201</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4888039VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4888039VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4888039VJ5648N_PI.201" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454687.311963071 4368585.93904964 454694.3060489 4368584.64087268 454693.628411888 4368580.6787384 454686.644450855 4368581.93694676 454687.311963071 4368585.93904964</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4889110VJ5648N_PI.202">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454698.920383825 4368735.75837848</gml:lowerCorner>
         <gml:upperCorner>454709.190383825 4368740.47837848</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4889110VJ5648N_PI.202</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4889110VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4889110VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4889110VJ5648N_PI.202" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454698.920383825 4368736.48837848 454699.210383825 4368740.47837848 454709.190383825 4368739.74837848 454708.890383825 4368735.75837848 454698.920383825 4368736.48837848</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4889506VJ5648N_PI.203">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454689.460304165 4368651.08707377</gml:lowerCorner>
         <gml:upperCorner>454695.943746623 4368662.53753109</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4889506VJ5648N_PI.203</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4889506VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4889506VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4889506VJ5648N_PI.203" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454690.643820421 4368662.53753109 454695.943746623 4368661.96072082 454694.760230523 4368651.08707377 454689.460304165 4368651.66393404 454690.643820421 4368662.53753109</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4989014VJ5648N_PI.204">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454812.500012819 4368701.7216889</gml:lowerCorner>
         <gml:upperCorner>454820.230794194 4368707.67957339</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4989014VJ5648N_PI.204</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4989014VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4989014VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4989014VJ5648N_PI.204" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 454813.149416279 4368707.67957339 454820.230794194 4368706.48136842 454819.425418175 4368701.7216889 454817.330330546 4368702.07620692 454817.592082798 4368703.17380143 454812.500012819 4368704.09680056 454813.149416279 4368707.67957339</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4989016VJ5648N_PI.205">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454788.616597428 4368700.07760791</gml:lowerCorner>
         <gml:upperCorner>454794.040310051 4368706.94190166</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4989016VJ5648N_PI.205</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4989016VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4989016VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4989016VJ5648N_PI.205" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 454788.616597428 4368700.58936348 454789.108974984 4368704.84144113 454791.229993125 4368704.60023158 454791.230334195 4368706.93025301 454794.040310051 4368706.94190166 454793.018756698 4368700.07760791 454788.616597428 4368700.58936348</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4989021VJ5648N_PI.206">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454773.129955575 4368727.63073101</gml:lowerCorner>
         <gml:upperCorner>454782.712826049 4368734.23382892</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4989021VJ5648N_PI.206</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4989021VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4989021VJ5648N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4989021VJ5648N_PI.206" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 454781.436437737 4368727.63073101 454773.129955575 4368728.97215862 454773.775198238 4368732.96761775 454778.144961177 4368732.26192622 454778.394799732 4368733.8090752 454782.712826049 4368734.23382892 454781.436437737 4368727.63073101</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4990901VJ5649S_PI.207">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454895.5931601 4368938.11879123</gml:lowerCorner>
         <gml:upperCorner>454900.61600855 4368946.55773102</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4990901VJ5649S_PI.207</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4990901VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4990901VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4990901VJ5649S_PI.207" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17"> 454900.61600855 4368946.38612567 454900.181864315 4368938.11879123 454896.88291727 4368938.29039658 454896.523514313 4368938.38275195 454896.204699822 4368938.56484347 454895.926408318 4368938.82667135 454895.728442502 4368939.13797431 454895.610736892 4368939.48875257 454895.5931601 4368939.8588756 454895.655516112 4368940.218475 454895.807739234 4368940.55748551 454896.039633238 4368940.84597324 454896.331133072 4368941.07406937 454896.67210799 4368941.22183982 454897.042492941 4368941.27941575 454897.317061505 4368946.55773102 454900.61600855 4368946.38612567</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4990920VJ5649S_PI.208">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454869.79509643 4368859.32128543</gml:lowerCorner>
         <gml:upperCorner>454877.274561918 4368863.75192019</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4990920VJ5649S_PI.208</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4990920VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4990920VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4990920VJ5649S_PI.208" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454877.274561918 4368862.24716282 454876.635389421 4368859.32128543 454869.79509643 4368860.82610828 454870.444268713 4368863.75192019 454877.274561918 4368862.24716282</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.4992411VJ5649S_PI.209">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454812.977 4368952.674</gml:lowerCorner>
         <gml:upperCorner>454816.1655 4368956.9875</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2026-04-10T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>4992411VJ5649S_PI.209</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=4992411VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=4992411VJ5649S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.4992411VJ5649S_PI.209" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454813.329 4368956.9875 454816.1655 4368956.5235 454815.859 4368952.674 454812.977 4368953.017 454813.329 4368956.9875</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.5087022VJ5658N_PI.210">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454853.67 4368503.96</gml:lowerCorner>
         <gml:upperCorner>454859.24 4368508.67</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-02-15T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>5087022VJ5658N_PI.210</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=5087022VJ5658N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=5087022VJ5658N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.5087022VJ5658N_PI.210" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 454853.67 4368506.08 454854.95 4368508.67 454859.24 4368506.55 454857.95 4368503.96 454853.67 4368506.08</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.5187014VJ5658N_PI.211">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455182.116247383 4368505.40097065</gml:lowerCorner>
         <gml:upperCorner>455190.360460774 4368514.715858</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>5187014VJ5658N_PI.211</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=5187014VJ5658N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=5187014VJ5658N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.5187014VJ5658N_PI.211" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 455185.544547531 4368505.40097065 455182.116247383 4368507.7790493 455186.932125811 4368514.715858 455190.360460774 4368512.32777941 455185.544547531 4368505.40097065</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.5289016VJ5658N_PI.212">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>455275.78 4368623.41</gml:lowerCorner>
         <gml:upperCorner>455287.81 4368631.37</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>5289016VJ5658N_PI.212</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=5289016VJ5658N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=5289016VJ5658N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.5289016VJ5658N_PI.212" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 455275.78 4368624.95 455277.03 4368631.37 455287.81 4368629.27 455286.67 4368623.41 455275.78 4368624.95</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.5594908VJ5659S_PI.213">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>454977.08 4369203.65</gml:lowerCorner>
         <gml:upperCorner>454983.32 4369213.46</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2014-12-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>5594908VJ5659S_PI.213</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=5594908VJ5659S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=5594908VJ5659S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.5594908VJ5659S_PI.213" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7"> 454977.26 4369203.65 454977.08 4369208.82 454979.94 4369208.82 454979.94 4369213.46 454983.32 4369213.46 454983.32 4369205.26 454977.26 4369203.65</gml:posList>
                    </gml:LinearRing>
                  </gml:exterior>
                </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
</gml:FeatureCollection>
